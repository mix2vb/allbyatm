import 'package:flutter/material.dart';
import 'services/database_service.dart';
import 'screens/setup_screen.dart'; // هنعملها حالاً
import 'screens/login_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // تشغيل ملف الإعدادات لمعرفة هل التطبيق مسجل من قبل أم لا
  await DatabaseService.initConfig();

  runApp(const PassLocalByATM());
}

class PassLocalByATM extends StatefulWidget {
  const PassLocalByATM({Key? key}) : super(key: key);

  @override
  State<PassLocalByATM> createState() => _PassLocalByATMState();
}

class _PassLocalByATMState extends State<PassLocalByATM> {
  // وضع الثيم الافتراضي (داكن أو فاتح)
  ThemeMode _themeMode = ThemeMode.light;// تم التغيير إلى نهاري افتراضيًا

  void toggleTheme(bool isDark) {
    setState(() {
      _themeMode = isDark ? ThemeMode.dark : ThemeMode.light;
    });
  }

  @override
  Widget build(BuildContext context) {
    // كود لاحتواء ميزة تغيير الإضاءة (ليلي / نهاري) وتمريرها للتطبيق
    return ThemeProvider(
      toggleTheme: toggleTheme,
      isDark: _themeMode == ThemeMode.dark,
      child: MaterialApp(
        title: 'PassLocalByATM',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar', 'AE'),
        localizationsDelegates: const [
          DefaultMaterialLocalizations.delegate,
          DefaultWidgetsLocalizations.delegate,
        ],
        theme: ThemeData.light().copyWith(
          scaffoldBackgroundColor: const Color(0xFFF5F5F5),
          appBarTheme: const AppBarTheme(backgroundColor: Colors.white, iconTheme: IconThemeData(color: Colors.black)),
        ),
        darkTheme: ThemeData.dark().copyWith(
          scaffoldBackgroundColor: const Color(0xFF121212),
          appBarTheme: const AppBarTheme(backgroundColor: const Color(0xFF1E1E1E)),
        ),
        themeMode: _themeMode,
        // لو أول مرة يفتح يروح لشاشة الإعداد، لو مش أول مرة يروح لشاشة تسجيل الدخول
        home: DatabaseService.isFirstTime() ? const SetupScreen() : const LoginScreen(),
      ),
    );
  }
}

// كود عبقري صغير عشان نقدر نغير الثيم من أي شاشة جوه التطبيق بسهولة
class ThemeProvider extends InheritedWidget {
  final Function(bool) toggleTheme;
  final bool isDark;

  const ThemeProvider({
    Key? key,
    required this.toggleTheme,
    required this.isDark,
    required Widget child,
  }) : super(key: key, child: child);

  static ThemeProvider? of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<ThemeProvider>();
  }

  @override
  bool updateShouldNotify(ThemeProvider oldWidget) => isDark != oldWidget.isDark;
}