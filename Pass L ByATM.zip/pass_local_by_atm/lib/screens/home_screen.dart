import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:file_picker/file_picker.dart';
import 'package:uuid/uuid.dart';
import '../main.dart';
import '../models/password_model.dart';
import '../services/database_service.dart';
import '../services/backup_service.dart';
import '../services/update_service.dart';
import 'add_password_screen.dart';
import 'login_screen.dart';
import 'support_and_contact.dart'; // استيراد صفحة الدعم والتواصل المضافة

class HomeScreen extends StatefulWidget {
  final String masterPassword;
  const HomeScreen({Key? key, required this.masterPassword}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  List<PasswordModel> _allPasswords = [];
  List<PasswordModel> _filteredPasswords = [];
  List<Map<String, dynamic>> _allNotes = [];

  String _searchQuery = '';
  String _selectedFolder = 'الكل';
  final List<String> _folders = ['الكل', 'المفضلة', 'شخصي', 'عمل', 'شبكات', 'عام'];
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 2, vsync: this);
    _loadData();

    WidgetsBinding.instance.addPostFrameCallback((_) {
      UpdateService.checkUpdates(context);
    });
  }

  void _loadData() {
    setState(() {
      _allPasswords = DatabaseService.getAllPasswords();
      _allNotes = DatabaseService.getAllNotes();
      _filterPasswords();
    });
  }

  Future<void> _handleRefresh() async {
    _loadData();
    await UpdateService.checkUpdates(context);
  }

  void _triggerAutoBackup() async {
    await BackupService.exportBackupSilent(widget.masterPassword);
  }

  void _filterPasswords() {
    setState(() {
      _filteredPasswords = _allPasswords.where((item) {
        final matchesSearch = item.title.toLowerCase().contains(_searchQuery.toLowerCase()) || item.username.toLowerCase().contains(_searchQuery.toLowerCase());
        if (_selectedFolder == 'الكل') return matchesSearch;
        if (_selectedFolder == 'المفضلة') return item.isFavorite && matchesSearch;
        return item.folder == _selectedFolder && matchesSearch;
      }).toList();
    });
  }

  // 🔒 دالة الاستيراد الأمنية والمطورة لطلب كلمة السر والأسئلة معاً
  void _importBackupWithSecurityCheck() async {
    // 1. اختيار ملف الباك أب أولاً
    FilePickerResult? result = await FilePicker.platform.pickFiles(type: FileType.any);
    if (result == null || result.files.single.path == null) return;

    final filePath = result.files.single.path!;
    final questions = DatabaseService.getSecurityQuestions();

    final passwordCtrl = TextEditingController();
    final answer1Ctrl = TextEditingController();
    final answer2Ctrl = TextEditingController();

    if (!mounted) return;

    // 2. فتح نافذة التحقق الأمني الموحد قبل الحاقن البرمي
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        title: const Row(
          children: [
            Icon(Icons.file_download_rounded, color: Colors.orange),
            SizedBox(width: 8),
            Text('تأكيد الهوية للاستيراد', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text('حماية الخصوصية: لدمج ملف النسخة الاحتياطية، يرجى إدخال بيانات الاعتماد المشفرة للتطبيق أولاً:', style: TextStyle(fontSize: 12, color: Colors.grey)),
              const SizedBox(height: 12),
              TextField(
                controller: passwordCtrl,
                obscureText: true,
                decoration: const InputDecoration(hintText: 'كلمة السر الرئيسية (Master)', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              Text('س١: ${questions['q1']}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              TextField(
                controller: answer1Ctrl,
                decoration: const InputDecoration(hintText: 'إجابة السؤال الأول', border: OutlineInputBorder()),
              ),
              const SizedBox(height: 12),
              Text('س٢: ${questions['q2']}', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600)),
              const SizedBox(height: 4),
              TextField(
                controller: answer2Ctrl,
                decoration: const InputDecoration(hintText: 'إجابة السؤال الثاني', border: OutlineInputBorder()),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
            onPressed: () async {
              // التحقق من صحة كلمة السر والأسئلة السرية المخزنة بالتطبيق
              bool isMasterValid = DatabaseService.verifyMasterPassword(passwordCtrl.text);
              bool isAnswersValid = DatabaseService.verifySecurityAnswers(answer1Ctrl.text, answer2Ctrl.text);

              if (isMasterValid && isAnswersValid) {
                Navigator.pop(context); // إغلاق النافذة

                // دمج البيانات وفك التشفير الحديدي
                bool success = await BackupService.importBackup(filePath, passwordCtrl.text);
                if (success) {
                  _loadData();
                  _showSnackBar('تم فك التشفير واستيراد البيانات بنجاح! 📥');
                } else {
                  _showSnackBar('فشل فك تشفير الملف! قد تكون النسخة تالفة أو كلمة السر غير مطابقة للملف.');
                }
              } else {
                _showSnackBar('بيانات التحقق غير صحيحة! تم حظر عملية الاستيراد.');
              }
            },
            child: const Text('تأكيد الاستيراد'),
          )
        ],
      ),
    );
  }

  // دالة تفريغ وحذف مجلد الباك أب نهائياً من الهاتف لمنع الثغرات
  void _purgeBackupFolder() async {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('تدمير النسخ الاحتياطية؟ ⚠️'),
        content: const Text('سيتم حذف وتفريغ مجلد الباك أب بالكامل من الذاكرة الخارجية للجهاز نهائياً ولن تتمكن من استعادتها إلا إذا كنت شاركت الملف في مكان آخر.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () async {
              Navigator.pop(context);
              bool deleted = await BackupService.clearAllBackups();
              if (deleted) {
                _showSnackBar('تم تفريغ وحذف مجلد الـ Backup بالكامل من الجهاز! 🪓');
              } else {
                _showSnackBar('المجلد فارغ بالفعل أو غير موجود.');
              }
            },
            child: const Text('احذف وتخلص منه'),
          )
        ],
      ),
    );
  }

  void _showOptionsBottomSheet(PasswordModel item) {
    showModalBottomSheet(
      context: context,
      builder: (context) => Container(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(item.title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            const Divider(),
            ListTile(
              leading: const Icon(Icons.copy_rounded, color: Colors.blue),
              title: const Text('نسخ اسم المستخدم (اليوزر)'),
              onTap: () {
                Clipboard.setData(ClipboardData(text: item.username));
                Navigator.pop(context);
                _showSnackBar('تم نسخ اسم المستخدم! 👤');
              },
            ),
            ListTile(
              leading: const Icon(Icons.password_rounded, color: Colors.green),
              title: const Text('نسخ كلمة السر (الباصوورد)'),
              onTap: () {
                Clipboard.setData(ClipboardData(text: item.password));
                Navigator.pop(context);
                _showSnackBar('تم نسخ كلمة السر! 🔐');
              },
            ),
            ListTile(
              leading: const Icon(Icons.edit_rounded, color: Colors.orange),
              title: const Text('تعديل بيانات الحساب'),
              onTap: () async {
                Navigator.pop(context);
                await Navigator.push(context, MaterialPageRoute(builder: (context) => AddPasswordScreen(existingItem: item)));
                _loadData();
                _triggerAutoBackup();
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete_rounded, color: Colors.red),
              title: const Text('حذف الحساب نهائياً'),
              onTap: () async {
                Navigator.pop(context);
                await DatabaseService.deletePassword(item.id);
                _loadData();
                _triggerAutoBackup();
                _showSnackBar('تم حذف الحساب بنجاح');
              },
            ),
          ],
        ),
      ),
    );
  }

  void _openNoteDialog({Map<String, dynamic>? note}) {
    final titleCtrl = TextEditingController(text: note?['title'] ?? '');
    final contentCtrl = TextEditingController(text: note?['content'] ?? '');

    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(note == null ? 'حفظ بيان / نوت سري' : 'تعديل النوت'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(controller: titleCtrl, decoration: const InputDecoration(hintText: 'عنوان البيان')),
            const SizedBox(height: 12),
            TextField(controller: contentCtrl, maxLines: 4, decoration: const InputDecoration(hintText: 'المعلومة المهمة')),
          ],
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
          if (note != null)
            TextButton(
              onPressed: () async {
                await DatabaseService.deleteNote(note['id']);
                Navigator.pop(context);
                _loadData();
                _triggerAutoBackup();
              },
              child: const Text('حذف', style: TextStyle(color: Colors.red)),
            ),
          ElevatedButton(
            onPressed: () async {
              if (titleCtrl.text.isNotEmpty && contentCtrl.text.isNotEmpty) {
                final id = note?['id'] ?? const Uuid().v4();
                await DatabaseService.saveNote(id, titleCtrl.text.trim(), contentCtrl.text.trim());
                Navigator.pop(context);
                _loadData();
                _triggerAutoBackup();
              }
            },
            child: const Text('حفظ بأمان'),
          )
        ],
      ),
    );
  }

  void _logout() async {
    await DatabaseService.closeDatabase();
    if (mounted) Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const LoginScreen()));
  }

  void _showSnackBar(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg, textDirection: TextDirection.rtl)));
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = ThemeProvider.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Pass L ByATM'),
        centerTitle: true,
        bottom: TabBar(
          controller: _tabController,
          tabs: const [
            Tab(icon: Icon(Icons.password_rounded), text: 'الحسابات'),
            Tab(icon: Icon(Icons.note_alt_rounded), text: 'الملاحظات'),
          ],
        ),
        leading: IconButton(
          icon: Icon(themeProvider!.isDark ? Icons.light_mode_rounded : Icons.dark_mode_rounded),
          onPressed: () => themeProvider.toggleTheme(!themeProvider.isDark),
        ),
        actions: [
          // 🪙 زر ادعمنا وتواصل معنا الجديد والمطلوب
          IconButton(
              icon: const Icon(Icons.volunteer_activism_rounded, color: Color(0xFF00ADB5)),
              tooltip: 'ادعمنا وتواصل معنا',
              onPressed: () {
                Navigator.push(context, MaterialPageRoute(builder: (context) => const SupportAndContactScreen()));
              }
          ),
          IconButton(
              icon: const Icon(Icons.save_alt_rounded, color: Colors.green),
              tooltip: 'حفظ صامت مشفر على الهاتف',
              onPressed: () async {
                String? path = await BackupService.exportBackupSilent(widget.masterPassword);
                if (path != null) {
                  _showSnackBar('تم الحفظ المشفر في مجلد Backup Pass Local ByATM 💾');
                } else {
                  _showSnackBar('فشل الحفظ الصامت!');
                }
              }
          ),
          IconButton(
              icon: const Icon(Icons.share_rounded, color: Colors.blue),
              tooltip: 'مشاركة الباك أب كود/كلاود مشفر',
              onPressed: () => BackupService.shareBackup(widget.masterPassword)
          ),
          IconButton(
              icon: const Icon(Icons.file_open_rounded, color: Colors.orange),
              tooltip: 'استعادة النسخة بالتحقق الأمني',
              onPressed: _importBackupWithSecurityCheck // استدعاء الدالة المحدثة بالأسئلة
          ),
          // 🪓 زر الحذف والتفريغ الذاتي للمجلد لحظر أي ثغرات استيراد
          IconButton(
              icon: const Icon(Icons.delete_forever_rounded, color: Colors.amber),
              tooltip: 'تفريغ وحذف مجلد الباك أب',
              onPressed: _purgeBackupFolder
          ),
          IconButton(
              icon: const Icon(Icons.logout_rounded, color: Colors.redAccent),
              tooltip: 'تسجيل خروج',
              onPressed: _logout
          ),
        ],
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          RefreshIndicator(
            color: const Color(0xFF00ADB5),
            onRefresh: _handleRefresh,
            child: ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: [
                Padding(
                  padding: const EdgeInsets.all(12.0),
                  child: TextField(
                    onChanged: (v) { _searchQuery = v; _filterPasswords(); },
                    decoration: InputDecoration(hintText: 'ابحث هنا...', prefixIcon: const Icon(Icons.search_rounded), border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))),
                  ),
                ),
                SizedBox(
                  height: 45,
                  child: ListView.builder(
                    scrollDirection: Axis.horizontal,
                    itemCount: _folders.length,
                    itemBuilder: (context, i) => Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 4),
                      child: ChoiceChip(
                        label: Text(_folders[i]),
                        selected: _selectedFolder == _folders[i],
                        onSelected: (s) { if (s) setState(() { _selectedFolder = _folders[i]; _filterPasswords(); }); },
                      ),
                    ),
                  ),
                ),
                _filteredPasswords.isEmpty
                    ? const Padding(
                  padding: EdgeInsets.all(48.0),
                  child: Center(child: Text('لا توجد حسابات مضافة حالياً')),
                )
                    : ListView.builder(
                  shrinkWrap: true,
                  physics: const NeverScrollableScrollPhysics(),
                  itemCount: _filteredPasswords.length,
                  itemBuilder: (context, i) {
                    final item = _filteredPasswords[i];
                    return Card(
                      child: ListTile(
                        onTap: () => _showOptionsBottomSheet(item),
                        onLongPress: () {
                          Clipboard.setData(ClipboardData(text: item.password));
                          _showSnackBar('تم نسخ كلمة السر بسرعة! 🔐');
                        },
                        leading: CircleAvatar(child: Text(item.title.isNotEmpty ? item.title[0] : '?')),
                        title: Text(item.title, style: const TextStyle(fontWeight: FontWeight.bold)),
                        subtitle: Text(item.username),
                        trailing: IconButton(
                          icon: Icon(item.isFavorite ? Icons.star_rounded : Icons.star_border_rounded, color: item.isFavorite ? Colors.amber : Colors.grey),
                          onPressed: () async {
                            item.isFavorite = !item.isFavorite;
                            await DatabaseService.savePassword(item);
                            _loadData();
                            _triggerAutoBackup();
                          },
                        ),
                      ),
                    );
                  },
                )
              ],
            ),
          ),
          RefreshIndicator(
            color: const Color(0xFF00ADB5),
            onRefresh: _handleRefresh,
            child: _allNotes.isEmpty
                ? ListView(
              physics: const AlwaysScrollableScrollPhysics(),
              children: const [
                Padding(
                  padding: EdgeInsets.all(64.0),
                  child: Center(child: Text('لا توجد ملاحظات سرية مضافة')),
                )
              ],
            )
                : ListView.builder(
              physics: const AlwaysScrollableScrollPhysics(),
              itemCount: _allNotes.length,
              padding: const EdgeInsets.all(12),
              itemBuilder: (context, i) {
                final note = _allNotes[i];
                return Card(
                  color: themeProvider!.isDark ? const Color(0xFF1E1E1E) : Colors.amber.shade50,
                  child: ListTile(
                    title: Text(note['title'], style: const TextStyle(fontWeight: FontWeight.bold)),
                    subtitle: Text(note['content'], maxLines: 3, overflow: TextOverflow.ellipsis),
                    trailing: const Icon(Icons.edit_note_rounded),
                    onTap: () => _openNoteDialog(note: note),
                    onLongPress: () {
                      Clipboard.setData(ClipboardData(text: note['content']));
                      _showSnackBar('تم نسخ نص الملاحظة السري! 📋');
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: const Color(0xFF00ADB5),
        child: const Icon(Icons.add, color: Colors.white),
        onPressed: () async {
          if (_tabController.index == 0) {
            await Navigator.push(context, MaterialPageRoute(builder: (context) => const AddPasswordScreen()));
            _loadData();
            _triggerAutoBackup();
          } else {
            _openNoteDialog();
          }
        },
      ),
    );
  }
}