import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

class SupportAndContactScreen extends StatelessWidget {
  const SupportAndContactScreen({super.key});

  static const String _vodafoneCash = "01091499989";
  static const String _instaPay = "01091499989";

  static const String _whatsappEgypt = "+201091499989";
  static const String _whatsappKSA = "+966505735672";

  Future<void> _openWhatsApp(String phone) async {
    final cleanPhone = phone.replaceAll('+', '');
    final Uri whatsappUri = Uri.parse("whatsapp://send?phone=$cleanPhone");

    try {
      if (await canLaunchUrl(whatsappUri)) {
        await launchUrl(whatsappUri, mode: LaunchMode.externalApplication);
      } else {
        final Uri fallbackUri = Uri.parse("https://wa.me/$cleanPhone");
        await launchUrl(fallbackUri, mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      debugPrint("خطأ في فتح واتساب: $e");
    }
  }

  void _copyToClipboard(BuildContext context, String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('تم نسخ $label بنجاح!', style: const TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF00ADB5),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    // 🌟 معرفة هل الثيم الحالي المختار (أو ثيم الهاتف) هو الليلي أم النهاري ديناميكياً
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    // 🎨 تكييف الألوان الأساسية بناءً على حالة الثيم ليعطي تناسق ملوكي
    final backgroundColor = isDarkMode ? const Color(0xFF11141a) : const Color(0xFFF8FAFC);
    final cardColor = isDarkMode ? const Color(0xFF1a1f29) : Colors.white;
    final primaryTextColor = isDarkMode ? Colors.white : const Color(0xFF0F172A);
    final secondaryTextColor = isDarkMode ? const Color(0xFF94A3B8) : const Color(0xFF475569);
    final borderColor = isDarkMode ? Colors.white.withOpacity(0.06) : Colors.black.withOpacity(0.06);
    final shadowColor = isDarkMode ? Colors.black.withOpacity(0.3) : Colors.grey.withOpacity(0.1);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: backgroundColor, // يتغير تلقائياً
        appBar: AppBar(
          title: Text(
            'الدعم والتواصل',
            style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20, color: primaryTextColor),
          ),
          backgroundColor: cardColor, // يتغير تلقائياً مع الثيم
          elevation: 0,
          centerTitle: true,
          iconTheme: IconThemeData(color: primaryTextColor), // تلوين زر الرجوع تلقائياً
          shape: Border(
            bottom: BorderSide(color: borderColor, width: 1),
          ),
        ),
        body: SingleChildScrollView(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // قسم دعم التطبيق
              Row(
                children: [
                  const Icon(Icons.coffee_rounded, color: Color(0xFF00ADB5), size: 24),
                  const SizedBox(width: 8),
                  const Text(
                    'ادعم استمرار التطبيق',
                    style: TextStyle(color: Color(0xFF00ADB5), fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                'التطبيق مجاني ومفتوح المصدر بالكامل، إذا كان التطبيق مفيداً لك يمكنك دعم المطور لمواصلة التحديثات وسد الثغرات المتقدمة.',
                style: TextStyle(color: secondaryTextColor, height: 1.5, fontSize: 13, fontWeight: FontWeight.w500),
              ),
              const SizedBox(height: 20),

              _buildSupportCard(
                context,
                icon: Icons.phone_android_rounded,
                title: 'فودافون كاش (Vodafone Cash)',
                value: _vodafoneCash,
                cardColor: cardColor,
                textColor: primaryTextColor,
                subColor: secondaryTextColor,
                borderColor: borderColor,
                shadowColor: shadowColor,
                onCopy: () => _copyToClipboard(context, _vodafoneCash, 'رقم فودافون كاش'),
              ),
              const SizedBox(height: 14),

              _buildSupportCard(
                context,
                icon: Icons.account_balance_wallet_rounded,
                title: 'انستا باي (InstaPay Address)',
                value: _instaPay,
                cardColor: cardColor,
                textColor: primaryTextColor,
                subColor: secondaryTextColor,
                borderColor: borderColor,
                shadowColor: shadowColor,
                onCopy: () => _copyToClipboard(context, _instaPay, 'عنوان انستا باي'),
              ),

              const SizedBox(height: 40),

              // قسم الدعم الفني
              Row(
                children: [
                  const Icon(Icons.forum_rounded, color: Color(0xFF00ADB5), size: 24),
                  const SizedBox(width: 8),
                  const Text(
                    'تواصل معنا (الدعم الفني)',
                    style: TextStyle(color: Color(0xFF00ADB5), fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                'لديك اقتراح، مشكلة، أو ترغب في الإبلاغ عن ثغرة أمنية؟ تواصل معنا مباشرة عبر الواتساب على خطوطنا المباشرة المؤمنة المتاحة لك:',
                style: TextStyle(color: secondaryTextColor, height: 1.5, fontSize: 13, fontWeight: FontWeight.w500),
              ),
              const SizedBox(height: 20),

              _buildContactButton(
                title: 'الدعم الفني - الخط الرئيسي (مصر)',
                phone: _whatsappEgypt,
                textColor: primaryTextColor,
                borderColor: borderColor,
                shadowColor: shadowColor,
                onPressed: () => _openWhatsApp(_whatsappEgypt),
              ),
              const SizedBox(height: 14),

              _buildContactButton(
                title: 'الدعم الفني - خط الطوارئ (السعودية)',
                phone: _whatsappKSA,
                textColor: primaryTextColor,
                borderColor: borderColor,
                shadowColor: shadowColor,
                onPressed: () => _openWhatsApp(_whatsappKSA),
              ),

              const SizedBox(height: 50),
              _buildDeveloperSignature(cardColor, borderColor, shadowColor),
              const SizedBox(height: 20),
            ],
          ),
        ),
      ),
    );
  }

  // ويدجت الكروت الذكية المتوافقة ديناميكياً مع الألوان المقروءة من الثيم الرئيسي
  Widget _buildSupportCard(
      BuildContext context, {
        required IconData icon,
        required String title,
        required String value,
        required Color cardColor,
        required Color textColor,
        required Color subColor,
        required Color borderColor,
        required Color shadowColor,
        required VoidCallback onCopy,
      }) {
    return Container(
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: borderColor, width: 1),
        boxShadow: [
          BoxShadow(
            color: shadowColor,
            blurRadius: 10,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onCopy,
          borderRadius: BorderRadius.circular(16),
          splashColor: const Color(0xFF00ADB5).withOpacity(0.1),
          highlightColor: const Color(0xFF00ADB5).withOpacity(0.05),
          child: Padding(
            padding: const EdgeInsets.all(16.0),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(10),
                  decoration: BoxDecoration(
                    color: const Color(0xFF00ADB5).withOpacity(0.08),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: const Color(0xFF00ADB5), size: 26),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: TextStyle(color: textColor, fontSize: 14, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 5),
                      Text(value, style: TextStyle(color: subColor, fontSize: 15, fontWeight: FontWeight.w600, letterSpacing: 1.1)),
                    ],
                  ),
                ),
                IconButton(
                  icon: Icon(Icons.copy_all_rounded, color: subColor, size: 22),
                  onPressed: onCopy,
                  tooltip: 'نسخ الرقم',
                  splashRadius: 22,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // زر الواتساب التفاعلي الذكي
  Widget _buildContactButton({
    required String title,
    required String phone,
    required Color textColor,
    required Color borderColor,
    required Color shadowColor,
    required VoidCallback onPressed,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [const Color(0xFF25D366).withOpacity(0.12), const Color(0xFF128C7E).withOpacity(0.02)],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFF25D366).withOpacity(0.2), width: 1),
        boxShadow: [
          BoxShadow(
            color: shadowColor,
            blurRadius: 8,
            offset: const Offset(0, 4),
          )
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(16),
          splashColor: const Color(0xFF25D366).withOpacity(0.15),
          highlightColor: const Color(0xFF25D366).withOpacity(0.05),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 18),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF25D366).withOpacity(0.1),
                    shape: BoxShape.circle,
                  ),
                  child: const Icon(Icons.chat_bubble_rounded, color: Color(0xFF25D366), size: 24),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: TextStyle(color: textColor, fontSize: 14, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 3),
                      Text(phone, style: const TextStyle(color: Color(0xFF64748B), fontSize: 13, fontWeight: FontWeight.w500, letterSpacing: 1.0)),
                    ],
                  ),
                ),
                const Icon(Icons.arrow_back_ios_new_rounded, color: Color(0xFF25D366), size: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // 👑 ويدجت التوقيع الفاخر المتناسق مع وضع الإضاءة المختار
  Widget _buildDeveloperSignature(Color cardColor, Color borderColor, Color shadowColor) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 24),
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: const Color(0xFF00ADB5).withOpacity(0.3),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: shadowColor,
            blurRadius: 16,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Center(
        child: RichText(
          textAlign: TextAlign.center,
          text: const TextSpan(
            text: 'إنشاء ودعم وتطوير\n',
            style: TextStyle(
              color: Color(0xFF64748B),
              fontSize: 12,
              fontWeight: FontWeight.w500,
              height: 1.8,
              fontFamily: 'Tajawal',
            ),
            children: [
              TextSpan(
                text: 'أحمد طه مهنا',
                style: TextStyle(
                  color: Color(0xFF00ADB5),
                  fontSize: 19,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 0.5,
                  fontFamily: 'Tajawal',
                  shadows: [
                    Shadow(
                      color: Color(0xFF00ADB5),
                      blurRadius: 12,
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}