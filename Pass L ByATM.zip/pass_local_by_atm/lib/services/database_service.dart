import 'dart:convert';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:crypto/crypto.dart';
import '../models/password_model.dart';

class DatabaseService {
  static const String _boxName = 'secure_passwords_box';
  static const String _notesBoxName = 'secure_notes_box';
  static const String _configBoxName = 'app_config_box';

  // جعلنا الـ Boxes عامة للوصول الآمن من ملف الـ Backup
  static Box? box;
  static Box? notesBox;
  static Box? configBox;

  static Future<void> initConfig() async {
    await Hive.initFlutter();
    configBox = await Hive.openBox(_configBoxName);
  }

  static bool isFirstTime() => configBox?.get('is_first_time', defaultValue: true) ?? true;

  static Future<void> saveSetup(String masterPassword, String q1, String a1, String q2, String a2) async {
    final passwordHash = sha256.convert(utf8.encode(masterPassword)).toString();
    final encryptedMaster = base64Encode(utf8.encode(masterPassword));

    await configBox?.put('password_hash', passwordHash);
    await configBox?.put('secure_master', encryptedMaster);
    await configBox?.put('q1', q1);
    await configBox?.put('a1', a1.trim().toLowerCase());
    await configBox?.put('q2', q2);
    await configBox?.put('a2', a2.trim().toLowerCase());
    await configBox?.put('is_first_time', false);
  }

  static String getSavedMaster() {
    final base64Str = configBox?.get('secure_master', defaultValue: '');
    if (base64Str.isEmpty) return '';
    return utf8.decode(base64Decode(base64Str));
  }

  static bool verifyMasterPassword(String inputPassword) {
    final inputHash = sha256.convert(utf8.encode(inputPassword)).toString();
    return inputHash == configBox?.get('password_hash');
  }

  static Map<String, String> getSecurityQuestions() {
    return {
      'q1': configBox?.get('q1', defaultValue: 'ما هو اسم أول مدرسة التحقت بها؟') ?? '',
      'q2': configBox?.get('q2', defaultValue: 'ما هي مدينتك المفضلة؟') ?? '',
    };
  }

  static String getSavedAnswer1() => configBox?.get('a1', defaultValue: '') ?? '';
  static String getSavedAnswer2() => configBox?.get('a2', defaultValue: '') ?? '';

  static bool verifySecurityAnswers(String a1, String a2) {
    return a1.trim().toLowerCase() == getSavedAnswer1() && a2.trim().toLowerCase() == getSavedAnswer2();
  }

  static Future<bool> initDatabase(String masterPassword) async {
    final keyBytes = utf8.encode(masterPassword);
    final encryptionKey = sha256.convert(keyBytes).bytes;

    try {
      box = await Hive.openBox(_boxName, encryptionCipher: HiveAesCipher(encryptionKey));
      notesBox = await Hive.openBox(_notesBoxName, encryptionCipher: HiveAesCipher(encryptionKey));
      return true;
    } catch (e) {
      return false;
    }
  }

  static Future<void> savePassword(PasswordModel password) async => await box?.put(password.id, password.toMap());
  static List<PasswordModel> getAllPasswords() => box == null ? [] : box!.values.map((e) => PasswordModel.fromMap(e)).toList();
  static Future<void> deletePassword(String id) async => await box?.delete(id);

  static Future<void> saveNote(String id, String title, String content) async {
    await notesBox?.put(id, {'id': id, 'title': title, 'content': content, 'date': DateTime.now().toString()});
  }
  static List<Map<String, dynamic>> getAllNotes() {
    if (notesBox == null) return [];
    return notesBox!.values.map((e) => Map<String, dynamic>.from(e)).toList();
  }
  static Future<void> deleteNote(String id) async => await notesBox?.delete(id);

  static Future<void> closeDatabase() async {
    await box?.close();
    await notesBox?.close();
    box = null;
    notesBox = null;
  }
}