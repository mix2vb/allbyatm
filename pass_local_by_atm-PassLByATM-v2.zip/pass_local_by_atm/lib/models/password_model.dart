class PasswordModel {
  final String id;
  final String title;       // اسم الموقع (مثلاً: فيسبوك)
  final String url;         // الرابط
  final String username;    // اسم المستخدم
  final String password;    // كلمة السر
  final String folder;      // الفولدر (شخصي، شبكات، إلخ)
  bool isFavorite;          // هل في المفضلات؟

  PasswordModel({
    required this.id,
    required this.title,
    required this.url,
    required this.username,
    required this.password,
    required this.folder,
    this.isFavorite = false,
  });

  // بنحتاجها عشان نحول البيانات لـ Map ونخزنها في قاعدة البيانات المشفرة
  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'title': title,
      'url': url,
      'username': username,
      'password': password,
      'folder': folder,
      'isFavorite': isFavorite ? 1 : 0, // 1 يعني نعم، 0 يعني لا
    };
  }

  // بنحتاجها عشان نقرأ البيانات من قاعدة البيانات ونرجعها لشكلها الطبيعي جوه التطبيق
  factory PasswordModel.fromMap(Map<dynamic, dynamic> map) {
    return PasswordModel(
      id: map['id'] ?? '',
      title: map['title'] ?? '',
      url: map['url'] ?? '',
      username: map['username'] ?? '',
      password: map['password'] ?? '',
      folder: map['folder'] ?? 'عام',
      isFavorite: map['isFavorite'] == 1,
    );
  }
}