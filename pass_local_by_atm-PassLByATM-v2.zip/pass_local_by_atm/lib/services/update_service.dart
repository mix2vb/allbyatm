import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

class UpdateService {
  static const String _updateUrl = "https://allbyatm.shortaccess.com/p/updatallappbyatm.html";

  // رقم إصدار التطبيق الحالي الحقيقي كـ double للمقارنة الرياضية
  static const double currentVersion = 2;

  static Uri get _uri => Uri.parse(_updateUrl);

  static Future<void> checkUpdates(BuildContext context) async {
    try {
      final response = await http.get(_uri);

      if (response.statusCode == 200) {
        final String htmlContent = response.body;

        // RegExp يبحث عن المعرف لاستخراج قيمة الإصدار
        final RegExp regExp = RegExp(
          r'<div[^>]*id=["\x27]app-latest-version-apppasslocalbyatm["\x27][^>]*>([^<]+)</div>',
          caseSensitive: false,
        );

        final match = regExp.firstMatch(htmlContent);

        if (match != null) {
          String serverVersionStr = match.group(1)!.trim();
          double? serverVersion = double.tryParse(serverVersionStr);

          if (serverVersion != null && serverVersion > currentVersion) {
            if (context.mounted) {
              _showUpdateDialog(context, serverVersionStr);
            }
          }
        } else {
          // Fallback العبقري المساعد
          final RegExp fallbackRegExp = RegExp(r'app-latest-version-apppasslocalbyatm["\x27]?[^>]*>([\d\.]+)');
          final fallbackMatch = fallbackRegExp.firstMatch(htmlContent);

          if (fallbackMatch != null) {
            String serverVersionStr = fallbackMatch.group(1)!.trim();
            double? serverVersion = double.tryParse(serverVersionStr);

            if (serverVersion != null && serverVersion > currentVersion) {
              if (context.mounted) {
                _showUpdateDialog(context, serverVersionStr);
              }
            }
          }
        }
      }
    } catch (e) {
      debugPrint("خطأ أثناء فحص التحديثات: $e");
    }
  }

  static void _showUpdateDialog(BuildContext context, String newVersion) {
    showDialog(
      context: context,
      barrierDismissible: false,
      barrierColor: Colors.black.withOpacity(0.8),
      useRootNavigator: false,
      builder: (context) => WillPopScope(
        onWillPop: () async => false,
        child: AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Row(
            children: [
              const Icon(Icons.system_update_rounded, color: Color(0xFF00ADB5), size: 28),
              const SizedBox(width: 8),
              Text(
                'تحديث إجباري متوفر! V$newVersion',
                style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
              ),
            ],
          ),
          content: const Text(
            'يتوفر إصدار جديد وهام جداً من خزنة الأسرار المحلية يحتوي على تحسينات أمنية حرجة وسد ثغرات. يرجى التحديث الآن لمتابعة استخدام التطبيق وحماية بياناتك.',
            style: TextStyle(height: 1.5),
          ),
          actions: [
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF00ADB5),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
                onPressed: () async {
                  try {
                    await launchUrl(_uri, mode: LaunchMode.externalApplication);
                  } catch (e) {
                    debugPrint("فشل فتح الرابط: $e");
                  }
                },
                child: const Text(
                  'تحديث الآن وتنزيل الإصدار',
                  style: TextStyle(color: Colors.white, fontSize: 15, fontWeight: FontWeight.bold),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  } // ✅ هذا القوس كان ناقصاً
} // ✅ هذا القوس كان ناقصاً أيضاً