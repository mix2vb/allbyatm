import 'package:shared_preferences/shared_preferences.dart';

class AdsService {
  static const String _adsKey = "show_ads_enabled";

  // قراءة الحالة: القيمة الافتراضية true (الإعلانات تعمل لدعمك افتراضياً)
  static Future<bool> isAdsEnabled() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_adsKey) ?? true;
  }

  // حفظ الحالة
  static Future<void> setAdsEnabled(bool value) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_adsKey, value);
  }
}