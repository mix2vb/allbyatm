import 'dart:io';
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'database_service.dart';

class BackupService {

  static String _xorCipher(String input, String key) {
    List<int> inputBytes = utf8.encode(input);
    List<int> keyBytes = utf8.encode(key);
    List<int> outputBytes = [];

    for (int i = 0; i < inputBytes.length; i++) {
      outputBytes.add(inputBytes[i] ^ keyBytes[i % keyBytes.length]);
    }
    return base64Encode(outputBytes);
  }

  static String _xorDecipher(String base64Input, String key) {
    List<int> inputBytes = base64Decode(base64Input);
    List<int> keyBytes = utf8.encode(key);
    List<int> outputBytes = [];

    for (int i = 0; i < inputBytes.length; i++) {
      outputBytes.add(inputBytes[i] ^ keyBytes[i % keyBytes.length]);
    }
    return utf8.decode(outputBytes);
  }

  static Future<Directory> _getBackupDirectory() async {
    Directory? downloadsDir = Directory('/storage/emulated/0/Download');
    if (!await downloadsDir.exists()) {
      downloadsDir = await getExternalStorageDirectory();
    }
    return Directory("${downloadsDir!.path}/Backup_Pass_Local_ByATM");
  }

  // 1. تصدير صامت مشفر بالكامل
  static Future<String?> exportBackupSilent(String masterPassword) async {
    try {
      final passwords = DatabaseService.getAllPasswords();
      final notes = DatabaseService.getAllNotes();
      final contacts = DatabaseService.getAllContacts(); // جلب جهات الاتصال

      Map<String, dynamic> exportData = {
        'passwords': passwords.map((e) => e.toMap()).toList(),
        'notes': notes,
        'contacts': contacts, // حفظها في ملف الـ ATM المحلي
      };

      String rawJson = jsonEncode(exportData);
      String encryptedString = _xorCipher(rawJson, masterPassword);

      final backupDir = await _getBackupDirectory();
      if (!await backupDir.exists()) {
        await backupDir.create(recursive: true);
      }

      String formattedDate = DateFormat('yyyy-MM-dd_HH-mm-ss').format(DateTime.now());
      String filePath = "${backupDir.path}/secure_backup_$formattedDate.atm";

      final file = File(filePath);
      await file.writeAsString(encryptedString);

      return filePath;
    } catch (e) {
      return null;
    }
  }

  // 2. مشاركة نسخة مشفرة خارجياً
  static Future<void> shareBackup(String masterPassword) async {
    try {
      final passwords = DatabaseService.getAllPasswords();
      final notes = DatabaseService.getAllNotes();
      final contacts = DatabaseService.getAllContacts();

      Map<String, dynamic> exportData = {
        'passwords': passwords.map((e) => e.toMap()).toList(),
        'notes': notes,
        'contacts': contacts,
      };

      String rawJson = jsonEncode(exportData);
      String encryptedString = _xorCipher(rawJson, masterPassword);

      final tempDir = await getTemporaryDirectory();
      String filePath = "${tempDir.path}/PassL_Secure_Share.atm";

      final file = File(filePath);
      await file.writeAsString(encryptedString);

      await Share.shareXFiles([XFile(filePath)], text: 'نسخة احتياطية مشفرة بالكامل من Pass L ByATM');
    } catch (e) {
      // معالجة الخطأ عند الحاجة
    }
  }

  // 3. استيراد وفك التشفير محلياً من ملف .atm
  static Future<bool> importBackup(String filePath, String masterPassword) async {
    try {
      final file = File(filePath);
      String encryptedContent = await file.readAsString();

      String decryptedContent = _xorDecipher(encryptedContent, masterPassword);
      Map<String, dynamic> decodedData = jsonDecode(decryptedContent);

      if (decodedData.containsKey('passwords')) {
        final list = decodedData['passwords'] as List;
        for (var item in list) {
          final mapData = Map<String, dynamic>.from(item);
          await DatabaseService.box?.put(mapData['id'], mapData);
        }
      }

      if (decodedData.containsKey('notes')) {
        final notesList = decodedData['notes'] as List;
        for (var note in notesList) {
          final mapNote = Map<String, dynamic>.from(note);
          await DatabaseService.notesBox?.put(mapNote['id'], mapNote);
        }
      }

      // استيراد جهات الاتصال من ملف الـ ATM
      if (decodedData.containsKey('contacts')) {
        final contactsList = decodedData['contacts'] as List;
        final List<Map<String, dynamic>> parsedContacts = contactsList
            .map((e) => Map<String, dynamic>.from(e))
            .toList();

        final settingsBox = Hive.box('settings');
        await settingsBox.put('contacts_list', parsedContacts);
      }

      return true;
    } catch (e) {
      return false;
    }
  }

  // 4. حذف وتفريغ المجلد تماماً
  static Future<bool> clearAllBackups() async {
    try {
      final backupDir = await _getBackupDirectory();
      if (await backupDir.exists()) {
        await backupDir.delete(recursive: true);
        return true;
      }
      return false;
    } catch (e) {
      return false;
    }
  }

  // =========================================================================
  // الدوال الخاصة بالنسخ الاحتياطي السحابي (Cloud Sync)
  // =========================================================================

  // أ) توليد نسخة احتياطية مشفرة بالكامل كـ String جاهز للإرسال للسيرفر
  static Future<String?> getEncryptedBackupString(String masterPassword) async {
    try {
      final passwords = DatabaseService.getAllPasswords();
      final notes = DatabaseService.getAllNotes();
      final contacts = DatabaseService.getAllContacts();

      Map<String, dynamic> exportData = {
        'passwords': passwords.map((e) => e.toMap()).toList(),
        'notes': notes,
        'contacts': contacts,
      };

      String rawJson = jsonEncode(exportData);
      String encryptedString = _xorCipher(rawJson, masterPassword);
      return encryptedString;
    } catch (e) {
      return null;
    }
  }

  // ب) فك تشفير البيانات السحابية الآتية كـ String من الكلاود وحفظها
  static Future<bool> importBackupFromString(String encryptedData, String masterPassword) async {
    try {
      String decryptedContent = _xorDecipher(encryptedData, masterPassword);
      Map<String, dynamic> decodedData = jsonDecode(decryptedContent);

      if (decodedData.containsKey('passwords')) {
        final list = decodedData['passwords'] as List;
        for (var item in list) { // تم إصلاح الخطأ المطبعي هنا من item إلى list
          final mapData = Map<String, dynamic>.from(item);
          await DatabaseService.box?.put(mapData['id'], mapData);
        }
      }

      if (decodedData.containsKey('notes')) {
        final notesList = decodedData['notes'] as List;
        for (var note in notesList) {
          final mapNote = Map<String, dynamic>.from(note);
          await DatabaseService.notesBox?.put(mapNote['id'], mapNote);
        }
      }

      if (decodedData.containsKey('contacts')) {
        final contactsList = decodedData['contacts'] as List;
        final List<Map<String, dynamic>> parsedContacts = contactsList
            .map((e) => Map<String, dynamic>.from(e))
            .toList();

        final settingsBox = Hive.box('settings');
        await settingsBox.put('contacts_list', parsedContacts);
      }

      return true;
    } catch (e) {
      return false;
    }
  }
}