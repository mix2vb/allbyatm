import 'package:flutter/material.dart';
import 'services/database_service.dart';
import 'screens/setup_screen.dart';
import 'screens/login_screen.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // ⚡ تهيئة إعلانات جوجل للموبايل لتجنب أي انهيار للتطبيق
  await MobileAds.instance.initialize();

  // تشغيل وتهيئة الملفات والبوكسات بالكامل
  await DatabaseService.initConfig();

  runApp(const PassLocalByATM());
}

class PassLocalByATM extends StatefulWidget {
  const PassLocalByATM({Key? key}) : super(key: key);

  @override
  State<PassLocalByATM> createState() => _PassLocalByATMState();
}

// ⚡ قمنا بإضافة WidgetsBindingObserver لمراقبة حالة خروج ودخول التطبيق
class _PassLocalByATMState extends State<PassLocalByATM> with WidgetsBindingObserver {
  ThemeMode _themeMode = ThemeMode.light;

  // متغيرات لحساب وقت الخروج والعودة
  DateTime? _pausedTime;
  final GlobalKey<NavigatorState> _navigatorKey = GlobalKey<NavigatorState>();

  void toggleTheme(bool isDark) {
    setState(() {
      _themeMode = isDark ? ThemeMode.dark : ThemeMode.light;
    });
  }

  @override
  void initState() {
    super.initState();
    // تسجيل المراقب في نظام الأندرويد/iOS
    WidgetsBinding.instance.addObserver(this);
  }

  @override
  void dispose() {
    // إلغاء تسجيل المراقب عند إغلاق التطبيق نهائياً
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  // ⚡ هذه الدالة السحرية التي تكتشف متى يخرج المستخدم ومتى يعود
  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);

    if (state == AppLifecycleState.paused) {
      // تم الخروج للخلفية: نسجل الوقت الحالي بدقة
      _pausedTime = DateTime.now();
    } else if (state == AppLifecycleState.resumed) {
      // عاد المستخدم للتطبيق: نتحقق من الوقت المنقضي
      if (_pausedTime != null) {
        final difference = DateTime.now().difference(_pausedTime!).inSeconds;

        // إذا غاب المستخدم 30 ثانية أو أكثر، يتم طرده لشاشة الدخول تلقائياً
        if (difference >= 30) {
          _lockApp();
        }
        // تصفير مؤقت الخروج بعد الفحص
        _pausedTime = null;
      }
    }
  }

  // دالة قفل التطبيق وإعادة التوجيه لشاشة تسجيل الدخول
  void _lockApp() {
    // نتحقق أولاً أن المستخدم ليس في شاشة التهيئة الأولى (First Time)
    if (!DatabaseService.isFirstTime()) {
      _navigatorKey.currentState?.pushAndRemoveUntil(
        MaterialPageRoute(builder: (context) => const LoginScreen()),
            (route) => false, // حذف كل الصفحات السابقة من الذاكرة لضمان الأمان الفولاذي
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return ThemeProvider(
      toggleTheme: toggleTheme,
      isDark: _themeMode == ThemeMode.dark,
      child: Builder(
        builder: (context) {
          return MaterialApp(
            // ⚡ قمنا بربط الـ NavigatorKey لكي نستطيع عمل إغلاق وتوجيه من خارج شجرة الـ Build
            navigatorKey: _navigatorKey,
            title: 'PassLocalByATM',
            debugShowCheckedModeBanner: false,
            locale: const Locale('ar', 'AE'),
            localizationsDelegates: const [
              DefaultMaterialLocalizations.delegate,
              DefaultWidgetsLocalizations.delegate,
            ],
            theme: ThemeData(
              brightness: Brightness.light,
              scaffoldBackgroundColor: const Color(0xFFF5F5F5),
              appBarTheme: const AppBarTheme(
                backgroundColor: Colors.white,
                elevation: 1,
                iconTheme: IconThemeData(color: Color(0xFF0F172A)),
                titleTextStyle: TextStyle(color: Color(0xFF0F172A), fontSize: 18, fontFamily: 'Tajawal', fontWeight: FontWeight.bold),
              ),
              cardColor: Colors.white,
            ),
            darkTheme: ThemeData(
              brightness: Brightness.dark,
              scaffoldBackgroundColor: const Color(0xFF121212),
              appBarTheme: const AppBarTheme(
                backgroundColor: Color(0xFF1E1E1E),
                elevation: 1,
                iconTheme: IconThemeData(color: Colors.white),
                titleTextStyle: TextStyle(color: Colors.white, fontSize: 18, fontFamily: 'Tajawal', fontWeight: FontWeight.bold),
              ),
              cardColor: const Color(0xFF1E1E1E),
            ),
            themeMode: _themeMode,
            home: DatabaseService.isFirstTime() ? const SetupScreen() : const LoginScreen(),
          );
        },
      ),
    );
  }
}

class ThemeProvider extends InheritedWidget {
  final Function(bool) toggleTheme;
  final bool isDark;

  const ThemeProvider({
    Key? key,
    required this.toggleTheme,
    required this.isDark,
    required Widget child,
  }) : super(key: key, child: child);

  static ThemeProvider? of(BuildContext context) {
    return context.dependOnInheritedWidgetOfExactType<ThemeProvider>();
  }

  @override
  bool updateShouldNotify(ThemeProvider oldWidget) => isDark != oldWidget.isDark;
}