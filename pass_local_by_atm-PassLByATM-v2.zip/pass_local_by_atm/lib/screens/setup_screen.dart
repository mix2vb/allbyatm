import 'package:flutter/material.dart';
import '../services/database_service.dart';
import 'login_screen.dart';

class SetupScreen extends StatefulWidget {
  const SetupScreen({Key? key}) : super(key: key);

  @override
  State<SetupScreen> createState() => _SetupScreenState();
}

class _SetupScreenState extends State<SetupScreen> {
  final _formKey = GlobalKey<FormState>();
  final _passController = TextEditingController();
  final _a1Controller = TextEditingController();
  final _a2Controller = TextEditingController();

  String _q1 = 'ما هو اسم أول مدرسة التحقت بها؟';
  String _q2 = 'ما هي مدينتك المفضلة؟';

  void _completeSetup() async {
    if (_formKey.currentState!.validate()) {
      await DatabaseService.saveSetup(
        _passController.text,
        _q1, _a1Controller.text,
        _q2, _a2Controller.text,
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تمت التهيئة بنجاح! يمكنك الآن فتح الخزنة', textDirection: TextDirection.rtl)),
        );
        Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => const LoginScreen()));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('تهيئة الخزنة لأول مرة'), centerTitle: true),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              const Icon(Icons.security_rounded, size: 70, color: Color(0xFF00ADB5)),
              const SizedBox(height: 16),
              const Text('قم بإعداد كلمة السر الرئيسية وأسئلة الأمان الاسترجاعية', style: TextStyle(fontSize: 15)),
              const SizedBox(height: 24),
              TextFormField(
                controller: _passController,
                obscureText: true,
                validator: (v) => v!.length < 6 ? 'الباسوورد يجب أن لا يقل عن 6 أحرف' : null,
                decoration: InputDecoration(labelText: 'اختر كلمة السر الفولاذية (Master Password)', filled: true, border: OutlineInputBorder(borderRadius: BorderRadius.circular(12))),
              ),
              const SizedBox(height: 24),
              const Divider(color: Colors.grey),
              const SizedBox(height: 12),
              const Text('أسئلة الأمان (لاسترجاع البيانات عند النسيان):', style: TextStyle(fontWeight: FontWeight.bold)),
              const SizedBox(height: 16),
              DropdownButtonFormField<String>(
                value: _q1,
                items: ['ما هو اسم أول مدرسة التحقت بها؟', 'ما هو اسم حيوانك الأليف الأول؟'].map((s) => DropdownMenuItem(value: s, child: Text(s, style: const TextStyle(fontSize: 13)))).toList(),
                onChanged: (v) => _q1 = v!,
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _a1Controller,
                validator: (v) => v!.isEmpty ? 'الرجاء كتابة الإجابة' : null,
                decoration: const InputDecoration(labelText: 'إجابة السؤال الأول', filled: true),
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<String>(
                value: _q2,
                items: ['ما هي مدينتك المفضلة؟', 'ما هو اسم صديق طفولتك؟'].map((s) => DropdownMenuItem(value: s, child: Text(s, style: const TextStyle(fontSize: 13)))).toList(),
                onChanged: (v) => _q2 = v!,
              ),
              const SizedBox(height: 8),
              TextFormField(
                controller: _a2Controller,
                validator: (v) => v!.isEmpty ? 'الرجاء كتابة الإجابة' : null,
                decoration: const InputDecoration(labelText: 'إجابة السؤال الثاني', filled: true),
              ),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _completeSetup,
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF00ADB5)),
                  child: const Text('حفظ وإتمام التهيئة', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                ),
              )
            ],
          ),
        ),
      ),
    );
  }
}