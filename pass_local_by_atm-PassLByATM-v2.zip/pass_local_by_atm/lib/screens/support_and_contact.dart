import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import '../services/ads_service.dart'; // تأكد من مسار الاستيراد الصحيح

class SupportAndContactScreen extends StatefulWidget {
  const SupportAndContactScreen({super.key});

  @override
  State<SupportAndContactScreen> createState() => _SupportAndContactScreenState();
}

class _SupportAndContactScreenState extends State<SupportAndContactScreen> {
  static const String _vodafoneCash = "01091499989";
  static const String _instaPay = "01091499989";

  static const String _whatsappEgypt = "+201091499989";
  static const String _whatsappKSA = "+966505735672";

  // كلمة السر المحددة لإيقاف الإعلانات
  static const String _bypassPassword = "PassLByATM";

  bool _showAds = true;
  bool _isLoadingAdsState = true;

  @override
  void initState() {
    super.initState();
    _loadAdsState();
  }

  Future<void> _loadAdsState() async {
    final state = await AdsService.isAdsEnabled();
    if (mounted) {
      setState(() {
        _showAds = state;
        _isLoadingAdsState = false;
      });
    }
  }

  // دالة التحكم بالمفتاح (Switch)
  Future<void> _onAdsSwitchChanged(bool value) async {
    if (value == true) {
      // التفعيل لا يحتاج كلمة سر
      await _toggleAds(true);
    } else {
      // إيقاف الإعلانات يتطلب كلمة سر
      _showPasswordDialog();
    }
  }

  Future<void> _toggleAds(bool value) async {
    await AdsService.setAdsEnabled(value);
    setState(() {
      _showAds = value;
    });
    _showSnackBar(value
        ? 'شكراً لدعمك الملوكي بظهور الإعلانات! ❤️'
        : 'تم إيقاف الإعلانات بالكامل بنجاح. 👍');
  }

  // صندوق الحوار لطلب كلمة السر مع خيارات التفعيل والتواصل
  void _showPasswordDialog() {
    final TextEditingController passwordController = TextEditingController();
    bool isPasswordVisible = false;

    showDialog(
      context: context,
      barrierDismissible: false, // يجب التفاعل مع الصندوق لإغلاقه
      builder: (context) {
        return StatefulBuilder(
          builder: (context, setStateDialog) {
            return Directionality(
              textDirection: TextDirection.rtl,
              child: AlertDialog(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                title: const Row(
                  children: [
                    Icon(Icons.lock_outline_rounded, color: Color(0xFF00ADB5), size: 26),
                    SizedBox(width: 8),
                    Text(
                      'مطلوب كلمة السر',
                      style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold, fontSize: 16),
                    ),
                  ],
                ),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'إيقاف الإعلانات يتطلب كلمة مرور الإيقاف الخاصة بالمطور لدعم استمرار المشروع وتغطية تكاليف الخوادم.',
                      style: TextStyle(fontFamily: 'Tajawal', fontSize: 12, height: 1.5, color: Colors.grey),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: passwordController,
                      obscureText: !isPasswordVisible,
                      style: const TextStyle(fontSize: 14),
                      decoration: InputDecoration(
                        labelText: 'أدخل كلمة السر',
                        labelStyle: const TextStyle(fontFamily: 'Tajawal', fontSize: 13),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: Color(0xFF00ADB5), width: 1.5),
                        ),
                        prefixIcon: const Icon(Icons.password_rounded, color: Color(0xFF00ADB5)),
                        suffixIcon: IconButton(
                          icon: Icon(
                            isPasswordVisible ? Icons.visibility_off_outlined : Icons.visibility_outlined,
                            color: Colors.grey,
                          ),
                          onPressed: () {
                            setStateDialog(() {
                              isPasswordVisible = !isPasswordVisible;
                            });
                          },
                        ),
                      ),
                    ),
                  ],
                ),
                actionsAlignment: MainAxisAlignment.spaceBetween,
                actionsPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                actions: [
                  // صف أزرار التواصل والإلغاء والتأكيد
                  Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          // زر تواصل معي للحصول على الكلمة
                          TextButton.icon(
                            onPressed: () {
                              Navigator.pop(context);
                              _openWhatsApp(_whatsappEgypt);
                            },
                            icon: const Icon(Icons.chat_bubble_outline_rounded, size: 18),
                            label: const Text('تواصل معي', style: TextStyle(fontWeight: FontWeight.bold)),
                            style: TextButton.styleFrom(
                              foregroundColor: const Color(0xFF25D366),
                              textStyle: const TextStyle(fontFamily: 'Tajawal', fontSize: 13),
                            ),
                          ),
                          // زر إلغاء العملية
                          TextButton(
                            onPressed: () {
                              Navigator.pop(context);
                            },
                            child: const Text('إلغاء', style: TextStyle(color: Colors.grey, fontWeight: FontWeight.bold, fontFamily: 'Tajawal')),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      // زر تفعيل الإيقاف (التأكيد)
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: const Color(0xFF00ADB5),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                            padding: const EdgeInsets.symmetric(vertical: 12),
                          ),
                          onPressed: () async {
                            if (passwordController.text == _bypassPassword) {
                              Navigator.pop(context);
                              await _toggleAds(false);
                            } else {
                              _showSnackBar('كلمة السر خاطئة! يرجى التواصل مع المطور للحصول عليها.');
                            }
                          },
                          child: const Text(
                            'تأكيد الإيقاف',
                            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Tajawal', fontSize: 14),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }

  Future<void> _openWhatsApp(String phone) async {
    final cleanPhone = phone.replaceAll('+', '');
    final Uri whatsappUri = Uri.parse("whatsapp://send?phone=$cleanPhone");

    try {
      if (await canLaunchUrl(whatsappUri)) {
        await launchUrl(whatsappUri, mode: LaunchMode.externalApplication);
      } else {
        final Uri fallbackUri = Uri.parse("https://wa.me/$cleanPhone");
        await launchUrl(fallbackUri, mode: LaunchMode.externalApplication);
      }
    } catch (e) {
      debugPrint("خطأ في فتح واتساب: $e");
    }
  }

  void _copyToClipboard(BuildContext context, String text, String label) {
    Clipboard.setData(ClipboardData(text: text));
    _showSnackBar('تم نسخ $label بنجاح! 📋');
  }

  void _showSnackBar(String text) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(text, style: const TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xFF00ADB5),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    final backgroundColor = isDarkMode ? const Color(0xFF11141a) : const Color(0xFFF8FAFC);
    final cardColor = isDarkMode ? const Color(0xFF1a1f29) : Colors.white;
    final primaryTextColor = isDarkMode ? Colors.white : const Color(0xFF0F172A);
    final secondaryTextColor = isDarkMode ? const Color(0xFF94A3B8) : const Color(0xFF475569);
    final borderColor = isDarkMode ? Colors.white.withOpacity(0.06) : Colors.black.withOpacity(0.06);
    final shadowColor = isDarkMode ? Colors.black.withOpacity(0.2) : Colors.grey.withOpacity(0.05);

    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        backgroundColor: backgroundColor,
        appBar: AppBar(
          title: Text(
            'الدعم والتواصل',
            style: TextStyle(fontWeight: FontWeight.w900, fontSize: 18, color: primaryTextColor),
          ),
          backgroundColor: cardColor,
          elevation: 0,
          centerTitle: true,
          iconTheme: IconThemeData(color: primaryTextColor),
          shape: Border(bottom: BorderSide(color: borderColor, width: 1)),
        ),
        body: ListView(
          padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 24.0),
          physics: const BouncingScrollPhysics(),
          children: [
            // ================= قسم مفتاح التحكم بالإعلانات =================
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: cardColor,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(color: const Color(0xFF00ADB5).withOpacity(0.2), width: 1),
                boxShadow: [BoxShadow(color: shadowColor, blurRadius: 10, offset: const Offset(0, 4))],
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      color: const Color(0xFF00ADB5).withOpacity(0.08),
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.ads_click_rounded, color: Color(0xFF00ADB5), size: 24),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('عرض الإعلانات لدعم التطبيق', style: TextStyle(color: primaryTextColor, fontSize: 14, fontWeight: FontWeight.bold)),
                        const SizedBox(height: 4),
                        Text('بما أن التطبيق مجاني بالكامل، يمكنك تشغيل الإعلانات لدعمنا أو تعطيلها إذا كنت تفضل ذلك.', style: TextStyle(color: secondaryTextColor, fontSize: 11, height: 1.4)),
                      ],
                    ),
                  ),
                  _isLoadingAdsState
                      ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2, color: Color(0xFF00ADB5)))
                      : Switch.adaptive(
                    value: _showAds,
                    activeColor: const Color(0xFF00ADB5),
                    onChanged: _onAdsSwitchChanged, // تم التوجيه لدالة الفحص الذكي هنا
                  ),
                ],
              ),
            ),
            const SizedBox(height: 28),

            // ================= قسم دعم التطبيق ماديًا =================
            Row(
              children: [
                const Icon(Icons.coffee_rounded, color: Color(0xFF00ADB5), size: 22),
                const SizedBox(width: 8),
                Text('ادعم استمرار التطبيق', style: TextStyle(color: primaryTextColor, fontSize: 16, fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'التطبيق مجاني ومفتوح المصدر بالكامل، دعمك المادي يساعد المطور على تغطية التكاليف البرمجية ومواصلة التحديثات الأمنية المتقدمة.',
              style: TextStyle(color: secondaryTextColor, height: 1.5, fontSize: 12),
            ),
            const SizedBox(height: 16),

            _buildSupportCard(
              icon: Icons.phone_android_rounded,
              title: 'فودافون كاش (Vodafone Cash)',
              value: _vodafoneCash,
              cardColor: cardColor,
              textColor: primaryTextColor,
              subColor: secondaryTextColor,
              borderColor: borderColor,
              shadowColor: shadowColor,
              onCopy: () => _copyToClipboard(context, _vodafoneCash, 'رقم فودافون كاش'),
            ),
            const SizedBox(height: 12),

            _buildSupportCard(
              icon: Icons.account_balance_wallet_rounded,
              title: 'انستا باي (InstaPay Address)',
              value: _instaPay,
              cardColor: cardColor,
              textColor: primaryTextColor,
              subColor: secondaryTextColor,
              borderColor: borderColor,
              shadowColor: shadowColor,
              onCopy: () => _copyToClipboard(context, _instaPay, 'عنوان انستا باي'),
            ),
            const SizedBox(height: 32),

            // ================= قسم الدعم الفني =================
            Row(
              children: [
                const Icon(Icons.forum_rounded, color: Color(0xFF00ADB5), size: 22),
                const SizedBox(width: 8),
                Text('تواصل معنا (الدعم الفني)', style: TextStyle(color: primaryTextColor, fontSize: 16, fontWeight: FontWeight.bold)),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'لديك اقتراح، مشكلة، أو ترغب في الإبلاغ عن ثغرة أمنية؟ تواصل معنا مباشرة عبر الواتساب على خطوطنا المباشرة والمؤمنة:',
              style: TextStyle(color: secondaryTextColor, height: 1.5, fontSize: 12),
            ),
            const SizedBox(height: 16),

            _buildContactButton(
              title: 'الدعم الفني - الخط الرئيسي (مصر)',
              textColor: primaryTextColor,
              shadowColor: shadowColor,
              onPressed: () => _openWhatsApp(_whatsappEgypt),
            ),
            const SizedBox(height: 12),

            _buildContactButton(
              title: 'الدعم الفني - خط الطوارئ (السعودية)',
              textColor: primaryTextColor,
              shadowColor: shadowColor,
              onPressed: () => _openWhatsApp(_whatsappKSA),
            ),
            const SizedBox(height: 48),

            // ================= التوقيع الفني الراقي =================
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'تم التطوير بكل حب وشغف 💻',
                    style: TextStyle(color: secondaryTextColor.withOpacity(0.7), fontSize: 11),
                  ),
                  const SizedBox(height: 4),
                  const Text(
                    'ByATM • أحمد طه مهنا',
                    style: TextStyle(
                      color: Color(0xFF00ADB5),
                      fontWeight: FontWeight.bold,
                      fontSize: 13,
                      letterSpacing: 0.8,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSupportCard({
    required IconData icon,
    required String title,
    required String value,
    required Color cardColor,
    required Color textColor,
    required Color subColor,
    required Color borderColor,
    required Color shadowColor,
    required VoidCallback onCopy,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: cardColor,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: borderColor, width: 1),
        boxShadow: [BoxShadow(color: shadowColor, blurRadius: 8, offset: const Offset(0, 2))],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onCopy,
          borderRadius: BorderRadius.circular(14),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14.0, vertical: 12.0),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: const Color(0xFF00ADB5).withOpacity(0.06),
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Icon(icon, color: const Color(0xFF00ADB5), size: 22),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(title, style: TextStyle(color: textColor, fontSize: 13, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 3),
                      Text(value, style: TextStyle(color: subColor, fontSize: 13, fontWeight: FontWeight.w600, letterSpacing: 0.8)),
                    ],
                  ),
                ),
                Icon(Icons.copy_all_rounded, color: subColor.withOpacity(0.7), size: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildContactButton({
    required String title,
    required Color textColor,
    required Color shadowColor,
    required VoidCallback onPressed,
  }) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [const Color(0xFF25D366).withOpacity(0.08), const Color(0xFF128C7E).withOpacity(0.01)],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFF25D366).withOpacity(0.15), width: 1),
        boxShadow: [BoxShadow(color: shadowColor, blurRadius: 6, offset: const Offset(0, 2))],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onPressed,
          borderRadius: BorderRadius.circular(14),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
            child: Row(
              children: [
                const Icon(Icons.chat_bubble_rounded, color: Color(0xFF25D366), size: 20),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(
                    title,
                    style: TextStyle(color: textColor, fontSize: 13, fontWeight: FontWeight.bold),
                  ),
                ),
                const Icon(Icons.arrow_forward_ios_rounded, color: Color(0xFF25D366), size: 14),
              ],
            ),
          ),
        ),
      ),
    );
  }
}