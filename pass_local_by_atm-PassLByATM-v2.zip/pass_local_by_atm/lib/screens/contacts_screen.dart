import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:uuid/uuid.dart';
import 'package:flutter_contacts/flutter_contacts.dart';
import 'package:permission_handler/permission_handler.dart';
import '../services/database_service.dart';
import '../main.dart';

class ContactsScreen extends StatefulWidget {
  const ContactsScreen({Key? key}) : super(key: key);

  @override
  State<ContactsScreen> createState() => ContactsScreenState();
}

class ContactsScreenState extends State<ContactsScreen> {
  // ==================== متغيرات البيانات ====================
  List<Map<String, dynamic>> _allContacts = [];
  List<Map<String, dynamic>> _filteredContacts = [];
  List<Map<String, dynamic>> _displayedContacts = [];

  // ==================== متغيرات التحكم بالصفحات ====================
  int _pageSize = 100;
  int _currentPage = 1;
  String _selectedLetter = 'الكل';
  final List<int> _pageSizeOptions = [100, 500, 1000];

  // ==================== الأحرف الأبجدية ====================
  final List<String> _alphabet = [
    'الكل', 'أ', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'س', 'ش',
    'ص', 'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'هـ', 'و', 'ي'
  ];

  // ==================== متغيرات التحكم ====================
  final ScrollController _scrollController = ScrollController();
  final _searchController = TextEditingController();
  final _nameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _notesController = TextEditingController();

  String _selectedFolder = 'عام';
  bool _isFavorite = false;
  String _activeFilter = 'الكل';
  final List<String> _folders = ['شخصي', 'عمل', 'طوارئ', 'مستورد', 'عام'];

  // ==================== متغيرات العمليات ====================
  bool _isDeleting = false;
  bool _isImporting = false;
  bool _shouldCancel = false;

  // ==================== أكواد الدول ====================
  static const Map<String, String> _countryCodes = {
    '+2': 'مصر',
    '+966': 'السعودية',
    '+971': 'الإمارات',
    '+962': 'الأردن',
    '+965': 'الكويت',
    '+968': 'عُمان',
    '+973': 'البحرين',
    '+974': 'قطر',
    '+970': 'فلسطين',
    '+961': 'لبنان',
    '+963': 'سوريا',
    '+964': 'العراق',
    '+967': 'اليمن',
    '+218': 'ليبيا',
    '+216': 'تونس',
    '+213': 'الجزائر',
    '+212': 'المغرب',
    '+222': 'موريتانيا',
    '+249': 'السودان',
    '+252': 'الصومال',
    '+90': 'تركيا',
    '+44': 'بريطانيا',
    '+1': 'الولايات المتحدة',
    '+33': 'فرنسا',
    '+49': 'ألمانيا',
    '+39': 'إيطاليا',
    '+34': 'إسبانيا',
    '+7': 'روسيا',
    '+86': 'الصين',
    '+91': 'الهند',
    '+81': 'اليابان',
    '+82': 'كوريا الجنوبية',
    '+55': 'البرازيل',
    '+61': 'أستراليا',
  };

  // ==================== دورة حياة الشاشة ====================
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _loadContacts();
    });
    _searchController.addListener(_onSearchChanged);
  }

  @override
  void dispose() {
    _searchController.removeListener(_onSearchChanged);
    _scrollController.dispose();
    _searchController.dispose();
    _nameController.dispose();
    _phoneController.dispose();
    _notesController.dispose();
    super.dispose();
  }

  // ==================== دوال تحميل وعرض البيانات ====================

  void openContactDialogFromHome() {
    _openContactDialog();
  }

  void _loadContacts() {
    try {
      final data = DatabaseService.getAllContacts();
      setState(() {
        _allContacts = data.map((item) => Map<String, dynamic>.from(item)).toList();
        _applyFiltersAndSearch();
      });
    } catch (e) {
      debugPrint("Error loading contacts: $e");
    }
  }

  void _applyFiltersAndSearch() {
    final query = _searchController.text.trim().toLowerCase();
    List<Map<String, dynamic>> results = List.from(_allContacts);

    // فلترة المجلدات والمفضلة
    if (_activeFilter == 'المفضلة') {
      results = results.where((c) {
        final fav = c['isFavorite'];
        return fav == true || fav == 1 || fav == 'true' || fav == '1';
      }).toList();
    } else if (_activeFilter == 'مستورد') {
      results = results.where((c) => c['folder'] == 'مستورد' || (c['notes'] ?? '').toString().contains('مستورد')).toList();
    } else if (_activeFilter != 'الكل') {
      results = results.where((c) => c['folder'] == _activeFilter).toList();
    }

    // فلترة الحرف الأبجدي
    if (_selectedLetter != 'الكل') {
      results = results.where((c) {
        final name = (c['name'] ?? '').toString().trim();
        if (name.isEmpty) return false;

        String firstChar = name.substring(0, 1);
        if (['أ', 'إ', 'آ', 'ا'].contains(firstChar)) {
          firstChar = 'أ';
        }

        String filterChar = _selectedLetter;
        if (['أ', 'إ', 'آ', 'ا'].contains(filterChar)) {
          filterChar = 'أ';
        }

        return firstChar.toLowerCase() == filterChar.toLowerCase();
      }).toList();
    }

    // فلترة البحث
    if (query.isNotEmpty) {
      results = results.where((c) {
        final name = (c['name'] ?? '').toString().toLowerCase();
        final phone = (c['phone'] ?? '').toString();
        final notes = (c['notes'] ?? '').toString().toLowerCase();
        return name.contains(query) || phone.contains(query) || notes.contains(query);
      }).toList();
    }

    // ترتيب النتائج
    results.sort((a, b) {
      final aFavVal = a['isFavorite'];
      final bFavVal = b['isFavorite'];
      final aFav = (aFavVal == true || aFavVal == 1 || aFavVal == 'true' || aFavVal == '1') ? 1 : 0;
      final bFav = (bFavVal == true || bFavVal == 1 || bFavVal == 'true' || bFavVal == '1') ? 1 : 0;
      if (aFav != bFav) {
        return bFav.compareTo(aFav);
      }
      return (a['name'] ?? '').toString().compareTo((b['name'] ?? '').toString());
    });

    setState(() {
      _filteredContacts = results;
      _currentPage = 1;
      _paginateContacts();
    });
  }

  void _paginateContacts() {
    if (_filteredContacts.isEmpty) {
      setState(() {
        _displayedContacts = [];
      });
      return;
    }

    final limit = _pageSize == -1 ? _filteredContacts.length : _pageSize;
    final int start = (_currentPage - 1) * limit;
    int end = start + limit;

    if (end > _filteredContacts.length) {
      end = _filteredContacts.length;
    }

    if (start >= _filteredContacts.length) {
      _currentPage = 1;
      _paginateContacts();
      return;
    }

    setState(() {
      _displayedContacts = _filteredContacts.sublist(start, end);
    });
  }

  void _onSearchChanged() {
    _applyFiltersAndSearch();
  }

  int get _totalPages {
    if (_filteredContacts.isEmpty) return 1;
    if (_pageSize == -1) return 1;
    return (_filteredContacts.length / _pageSize).ceil();
  }

  // ==================== دوال مساعدة ====================

  void _showSnackBar(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'Tajawal', color: Colors.white)),
      backgroundColor: isError ? Colors.redAccent : const Color(0xFF00ADB5),
      behavior: SnackBarBehavior.floating,
    ));
  }

  String _cleanPhoneNumber(String phone) {
    return phone.replaceAll(RegExp(r'[\s\-()]+'), '');
  }

  // ==================== دوال الاتصال والرسائل ====================

  Future<void> _makePhoneCall(String phoneNumber) async {
    final Uri launchUri = Uri(scheme: 'tel', path: phoneNumber);
    if (await canLaunchUrl(launchUri)) {
      await launchUrl(launchUri);
    } else {
      _showSnackBar('تعذر إجراء المكالمة الهاتفية!', isError: true);
    }
  }

  Future<void> _sendSMS(String phoneNumber) async {
    final Uri launchUri = Uri(scheme: 'sms', path: phoneNumber);
    if (await canLaunchUrl(launchUri)) {
      await launchUrl(launchUri);
    } else {
      _showSnackBar('تعذر إرسال رسالة SMS!', isError: true);
    }
  }

  // ==================== دوال معالجة أكواد الدول ====================

  String? _extractCountryCode(String phone) {
    final cleaned = _cleanPhoneNumber(phone);
    if (cleaned.isEmpty) return null;

    final sortedCodes = _countryCodes.keys.toList()..sort((a, b) => b.length.compareTo(a.length));

    for (String code in sortedCodes) {
      if (cleaned.startsWith(code.replaceAll('+', ''))) {
        return code;
      }
      if (cleaned.startsWith(code)) {
        return code;
      }
    }
    return null;
  }

  String _ensureCountryCode(String phone, {String? selectedCountryCode}) {
    String cleaned = _cleanPhoneNumber(phone);
    if (cleaned.isEmpty) return phone;

    String? existingCode = _extractCountryCode(cleaned);
    if (existingCode != null) {
      return cleaned;
    }

    String codeToAdd = selectedCountryCode ?? '+966';
    codeToAdd = codeToAdd.replaceAll(RegExp(r'[^0-9+]'), '');
    if (!codeToAdd.startsWith('+')) {
      codeToAdd = '+$codeToAdd';
    }

    if (cleaned.startsWith('0')) {
      cleaned = cleaned.substring(1);
    }

    return '$codeToAdd$cleaned';
  }

  // ==================== دوال واتساب ====================

  Future<void> _openWhatsApp(String phoneNumber) async {
    try {
      String formattedPhone = _ensureCountryCode(phoneNumber);
      formattedPhone = formattedPhone.replaceAll(RegExp(r'[^0-9+]'), '');

      String? countryCode = _extractCountryCode(formattedPhone);
      if (countryCode == null) {
        _showCountryCodeDialog(phoneNumber);
        return;
      }

      final Uri whatsappUri = Uri.parse('https://wa.me/$formattedPhone');
      if (await canLaunchUrl(whatsappUri)) {
        await launchUrl(whatsappUri, mode: LaunchMode.externalApplication);
      } else {
        _showSnackBar('تعذر فتح واتساب! تأكد من تثبيت التطبيق.', isError: true);
      }
    } catch (e) {
      _showSnackBar('حدث خطأ: $e', isError: true);
    }
  }

  void _showCountryCodeDialog(String phoneNumber) {
    final TextEditingController codeController = TextEditingController(text: '+966');
    String? selectedCode = '+966';

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (dialogCtx) {
        final isDark = Theme.of(dialogCtx).brightness == Brightness.dark;
        final dialogBg = isDark ? const Color(0xFF1E1E1E) : Colors.white;
        final dialogTxt = isDark ? Colors.white : const Color(0xFF0F172A);

        return WillPopScope(
          onWillPop: () async => false,
          child: AlertDialog(
            backgroundColor: dialogBg,
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
            title: Row(
              children: [
                const Icon(Icons.info_outline_rounded, color: Color(0xFF00ADB5), size: 28),
                const SizedBox(width: 8),
                Text(
                  'مطلوب كود الدولة 🌍',
                  style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold, color: dialogTxt, fontSize: 16),
                ),
              ],
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'الرقم "$phoneNumber" لا يحتوي على كود دولة.\nالرجاء اختيار كود الدولة الصحيح للتواصل عبر واتساب:',
                  style: TextStyle(fontFamily: 'Tajawal', fontSize: 13, color: Colors.grey[600], height: 1.5),
                ),
                const SizedBox(height: 16),
                DropdownButtonFormField<String>(
                  value: selectedCode,
                  dropdownColor: dialogBg,
                  style: TextStyle(color: dialogTxt, fontFamily: 'Tajawal'),
                  decoration: InputDecoration(
                    labelText: 'اختر كود الدولة',
                    labelStyle: const TextStyle(fontSize: 13),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    prefixIcon: const Icon(Icons.flag_rounded, color: Color(0xFF00ADB5)),
                  ),
                  items: _countryCodes.entries.map((entry) {
                    return DropdownMenuItem(
                      value: entry.key,
                      child: Text('${entry.key} - ${entry.value}', style: const TextStyle(fontSize: 13)),
                    );
                  }).toList(),
                  onChanged: (value) {
                    selectedCode = value;
                    codeController.text = value ?? '+966';
                  },
                ),
                const SizedBox(height: 12),
                Text(
                  'أو يمكنك إدخال الكود يدوياً:',
                  style: TextStyle(fontFamily: 'Tajawal', fontSize: 12, color: Colors.grey[600]),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: codeController,
                  keyboardType: TextInputType.phone,
                  style: TextStyle(color: dialogTxt),
                  decoration: InputDecoration(
                    hintText: 'مثال: +966 أو 966',
                    hintStyle: const TextStyle(fontSize: 12, color: Colors.grey),
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    prefixIcon: const Icon(Icons.edit_rounded, color: Color(0xFF00ADB5), size: 20),
                    contentPadding: const EdgeInsets.symmetric(vertical: 12),
                  ),
                ),
              ],
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dialogCtx),
                child: const Text('إلغاء', style: TextStyle(fontFamily: 'Tajawal', color: Colors.grey)),
              ),
              ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF00ADB5),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {
                  String code = codeController.text.trim();
                  if (code.isEmpty) {
                    _showSnackBar('الرجاء إدخال كود الدولة.', isError: true);
                    return;
                  }

                  code = code.replaceAll(RegExp(r'[^0-9+]'), '');
                  if (!code.startsWith('+')) {
                    code = '+$code';
                  }

                  Navigator.pop(dialogCtx);
                  String fullNumber = _ensureCountryCode(phoneNumber, selectedCountryCode: code);
                  _openWhatsApp(fullNumber);
                },
                child: const Text('موافق وتابع 📱', style: TextStyle(color: Colors.white, fontFamily: 'Tajawal', fontWeight: FontWeight.bold)),
              ),
            ],
          ),
        );
      },
    );
  }

  // ==================== نافذة اختيار طريقة الإرسال ====================

  void _showMessageOptions(String phoneNumber) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (bottomCtx) {
        final isDark = Theme.of(bottomCtx).brightness == Brightness.dark;
        final bg = isDark ? const Color(0xFF1E1E1E) : Colors.white;
        final textColor = isDark ? Colors.white : const Color(0xFF0F172A);

        return Container(
          decoration: BoxDecoration(
            color: bg,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          ),
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 50,
                height: 5,
                decoration: BoxDecoration(
                  color: Colors.grey.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                'اختر طريقة الإرسال 📨',
                style: TextStyle(
                  fontFamily: 'Tajawal',
                  fontWeight: FontWeight.bold,
                  fontSize: 18,
                  color: textColor,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'للرقم: $phoneNumber',
                style: TextStyle(
                  fontFamily: 'Tajawal',
                  fontSize: 14,
                  color: Colors.grey[600],
                ),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              Row(
                children: [
                  Expanded(
                    child: InkWell(
                      onTap: () {
                        Navigator.pop(bottomCtx);
                        _sendSMS(phoneNumber);
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 20),
                        decoration: BoxDecoration(
                          color: Colors.blue.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: Colors.blue.withOpacity(0.3)),
                        ),
                        child: Column(
                          children: [
                            const Icon(Icons.sms_rounded, color: Colors.blue, size: 40),
                            const SizedBox(height: 8),
                            Text(
                              'رسالة عادية',
                              style: TextStyle(
                                fontFamily: 'Tajawal',
                                fontWeight: FontWeight.bold,
                                color: textColor,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'SMS 📱',
                              style: TextStyle(
                                fontFamily: 'Tajawal',
                                fontSize: 11,
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: InkWell(
                      onTap: () {
                        Navigator.pop(bottomCtx);
                        _openWhatsApp(phoneNumber);
                      },
                      child: Container(
                        padding: const EdgeInsets.symmetric(vertical: 20),
                        decoration: BoxDecoration(
                          color: const Color(0xFF25D366).withOpacity(0.1),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(color: const Color(0xFF25D366).withOpacity(0.3)),
                        ),
                        child: Column(
                          children: [
                            const Icon(Icons.chat_rounded, color: Color(0xFF25D366), size: 40),
                            const SizedBox(height: 8),
                            Text(
                              'واتساب',
                              style: TextStyle(
                                fontFamily: 'Tajawal',
                                fontWeight: FontWeight.bold,
                                color: textColor,
                                fontSize: 14,
                              ),
                            ),
                            const SizedBox(height: 4),
                            Text(
                              'WhatsApp 💬',
                              style: TextStyle(
                                fontFamily: 'Tajawal',
                                fontSize: 11,
                                color: Colors.grey[600],
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              TextButton(
                onPressed: () => Navigator.pop(bottomCtx),
                child: const Text(
                  'إلغاء',
                  style: TextStyle(
                    fontFamily: 'Tajawal',
                    color: Colors.grey,
                    fontSize: 14,
                  ),
                ),
              ),
              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }

  // ==================== نافذة كتابة الرقم والاتصال ====================

  void _showDialPad() {
    final TextEditingController phoneController = TextEditingController();
    String? selectedCountryCode = '+966';
    String formattedPhone = '';

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (bottomCtx) {
        final isDark = Theme.of(bottomCtx).brightness == Brightness.dark;
        final bg = isDark ? const Color(0xFF1E1E1E) : Colors.white;
        final textColor = isDark ? Colors.white : const Color(0xFF0F172A);

        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              decoration: BoxDecoration(
                color: bg,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
              ),
              padding: EdgeInsets.only(
                top: 24,
                left: 24,
                right: 24,
                bottom: MediaQuery.of(bottomCtx).viewInsets.bottom + 24,
              ),
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Container(
                      width: 50,
                      height: 5,
                      decoration: BoxDecoration(
                        color: Colors.grey.withOpacity(0.3),
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    const SizedBox(height: 20),
                    Row(
                      children: [
                        const Icon(Icons.dialpad_rounded, color: Color(0xFF00ADB5), size: 28),
                        const SizedBox(width: 12),
                        Text(
                          '📞 كتابة الرقم والاتصال',
                          style: TextStyle(
                            fontFamily: 'Tajawal',
                            fontWeight: FontWeight.bold,
                            fontSize: 20,
                            color: textColor,
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'أدخل رقم الهاتف واختر طريقة التواصل',
                      style: TextStyle(
                        fontFamily: 'Tajawal',
                        fontSize: 14,
                        color: Colors.grey[600],
                      ),
                    ),
                    const SizedBox(height: 20),

                    // اختيار كود الدولة
                    Container(
                      decoration: BoxDecoration(
                        color: const Color(0xFF00ADB5).withOpacity(0.05),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFF00ADB5).withOpacity(0.2)),
                      ),
                      padding: const EdgeInsets.symmetric(horizontal: 12),
                      child: DropdownButtonHideUnderline(
                        child: DropdownButton<String>(
                          value: selectedCountryCode,
                          dropdownColor: bg,
                          style: TextStyle(
                            color: textColor,
                            fontFamily: 'Tajawal',
                            fontSize: 14,
                            fontWeight: FontWeight.bold,
                          ),
                          icon: const Icon(Icons.flag_rounded, color: Color(0xFF00ADB5)),
                          isExpanded: true,
                          items: _countryCodes.entries.map((entry) {
                            return DropdownMenuItem(
                              value: entry.key,
                              child: Row(
                                children: [
                                  const Icon(Icons.flag_rounded, size: 16, color: Color(0xFF00ADB5)),
                                  const SizedBox(width: 8),
                                  Text(
                                    '${entry.key} - ${entry.value}',
                                    style: const TextStyle(fontSize: 13),
                                  ),
                                ],
                              ),
                            );
                          }).toList(),
                          onChanged: (value) {
                            setModalState(() {
                              selectedCountryCode = value;
                              final phone = phoneController.text.trim();
                              if (phone.isNotEmpty) {
                                formattedPhone = _ensureCountryCode(phone, selectedCountryCode: selectedCountryCode);
                              }
                            });
                          },
                        ),
                      ),
                    ),

                    const SizedBox(height: 16),

                    // حقل إدخال الرقم
                    TextField(
                      controller: phoneController,
                      keyboardType: TextInputType.phone,
                      style: TextStyle(
                        color: textColor,
                        fontSize: 18,
                        fontFamily: 'Tajawal',
                        fontWeight: FontWeight.bold,
                      ),
                      onChanged: (value) {
                        setModalState(() {
                          if (value.isNotEmpty) {
                            formattedPhone = _ensureCountryCode(value, selectedCountryCode: selectedCountryCode);
                          } else {
                            formattedPhone = '';
                          }
                        });
                      },
                      decoration: InputDecoration(
                        hintText: 'أدخل رقم الهاتف...',
                        hintStyle: TextStyle(
                          color: Colors.grey[400],
                          fontSize: 16,
                        ),
                        prefixIcon: const Icon(Icons.phone_rounded, color: Color(0xFF00ADB5)),
                        prefixText: '${selectedCountryCode ?? '+966'} ',
                        prefixStyle: TextStyle(
                          color: textColor,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: Colors.grey[300]!),
                        ),
                        enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: Colors.grey[300]!),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: Color(0xFF00ADB5), width: 2),
                        ),
                        contentPadding: const EdgeInsets.symmetric(vertical: 16),
                      ),
                    ),

                    const SizedBox(height: 8),

                    // عرض الرقم المنسق
                    if (formattedPhone.isNotEmpty)
                      Container(
                        padding: const EdgeInsets.all(8),
                        decoration: BoxDecoration(
                          color: Colors.green.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            const Icon(Icons.check_circle_rounded, color: Colors.green, size: 16),
                            const SizedBox(width: 8),
                            Text(
                              'سيتم الاتصال على: $formattedPhone',
                              style: TextStyle(
                                fontFamily: 'Tajawal',
                                fontSize: 13,
                                color: Colors.green[700],
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ),

                    const SizedBox(height: 24),

                    // أزرار الاتصال والرسائل
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            icon: const Icon(Icons.call_rounded, color: Colors.white, size: 24),
                            label: Text(
                              '📞 اتصال',
                              style: TextStyle(
                                fontFamily: 'Tajawal',
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: Colors.white,
                              ),
                            ),
                            onPressed: () {
                              final phone = phoneController.text.trim();
                              if (phone.isEmpty) {
                                _showSnackBar('الرجاء إدخال رقم الهاتف.', isError: true);
                                return;
                              }
                              final fullNumber = _ensureCountryCode(phone, selectedCountryCode: selectedCountryCode);
                              Navigator.pop(bottomCtx);
                              _makePhoneCall(fullNumber);
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton.icon(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: const Color(0xFF00ADB5),
                              padding: const EdgeInsets.symmetric(vertical: 16),
                              shape: RoundedRectangleBorder(
                                borderRadius: BorderRadius.circular(12),
                              ),
                            ),
                            icon: const Icon(Icons.message_rounded, color: Colors.white, size: 24),
                            label: Text(
                              '💬 رسالة',
                              style: TextStyle(
                                fontFamily: 'Tajawal',
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                                color: Colors.white,
                              ),
                            ),
                            onPressed: () {
                              final phone = phoneController.text.trim();
                              if (phone.isEmpty) {
                                _showSnackBar('الرجاء إدخال رقم الهاتف.', isError: true);
                                return;
                              }
                              final fullNumber = _ensureCountryCode(phone, selectedCountryCode: selectedCountryCode);
                              Navigator.pop(bottomCtx);
                              _showMessageOptions(fullNumber);
                            },
                          ),
                        ),
                      ],
                    ),

                    const SizedBox(height: 12),

                    // زر واتساب
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF25D366),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        icon: const Icon(Icons.chat_rounded, color: Colors.white, size: 24),
                        label: Text(
                          '💬 واتساب',
                          style: TextStyle(
                            fontFamily: 'Tajawal',
                            fontWeight: FontWeight.bold,
                            fontSize: 16,
                            color: Colors.white,
                          ),
                        ),
                        onPressed: () {
                          final phone = phoneController.text.trim();
                          if (phone.isEmpty) {
                            _showSnackBar('الرجاء إدخال رقم الهاتف.', isError: true);
                            return;
                          }
                          final fullNumber = _ensureCountryCode(phone, selectedCountryCode: selectedCountryCode);
                          Navigator.pop(bottomCtx);
                          _openWhatsApp(fullNumber);
                        },
                      ),
                    ),

                    const SizedBox(height: 12),

                    TextButton(
                      onPressed: () => Navigator.pop(bottomCtx),
                      child: Text(
                        'إلغاء',
                        style: TextStyle(
                          fontFamily: 'Tajawal',
                          color: Colors.grey[600],
                          fontSize: 14,
                        ),
                      ),
                    ),

                    const SizedBox(height: 8),
                  ],
                ),
              ),
            );
          },
        );
      },
    );
  }

  // ==================== دوال النسخ (الضغط المطول) ====================

  void _copyToClipboard(String text, String message) {
    Clipboard.setData(ClipboardData(text: text));
    _showSnackBar('✅ $message');
  }

  void _showLongPressOptions(Map<String, dynamic> contact) {
    final name = contact['name'] ?? '';
    final phone = contact['phone'] ?? '';

    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (bottomCtx) {
        final isDark = Theme.of(bottomCtx).brightness == Brightness.dark;
        final bg = isDark ? const Color(0xFF1E1E1E) : Colors.white;
        final textColor = isDark ? Colors.white : const Color(0xFF0F172A);

        return Container(
          decoration: BoxDecoration(
            color: bg,
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          ),
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                width: 50,
                height: 5,
                decoration: BoxDecoration(
                  color: Colors.grey.withOpacity(0.3),
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              const SizedBox(height: 20),
              Text(
                '📋 خيارات النسخ',
                style: TextStyle(
                  fontFamily: 'Tajawal',
                  fontWeight: FontWeight.bold,
                  fontSize: 20,
                  color: textColor,
                ),
              ),
              const SizedBox(height: 8),
              Text(
                'اختر ما تريد نسخه من جهة الاتصال',
                style: TextStyle(
                  fontFamily: 'Tajawal',
                  fontSize: 14,
                  color: Colors.grey[600],
                ),
              ),
              const SizedBox(height: 20),

              // معلومات جهة الاتصال
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: const Color(0xFF00ADB5).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: const Color(0xFF00ADB5).withOpacity(0.2)),
                ),
                child: Column(
                  children: [
                    Row(
                      children: [
                        const Icon(Icons.person_rounded, color: Color(0xFF00ADB5), size: 18),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            name.isNotEmpty ? name : 'بدون اسم',
                            style: TextStyle(
                              fontFamily: 'Tajawal',
                              fontWeight: FontWeight.bold,
                              color: textColor,
                              fontSize: 14,
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        const Icon(Icons.phone_rounded, color: Color(0xFF00ADB5), size: 18),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            phone.isNotEmpty ? phone : 'لا يوجد رقم',
                            style: TextStyle(
                              fontFamily: 'Tajawal',
                              color: Colors.grey[600],
                              fontSize: 14,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 20),
              const Divider(height: 1),

              // خيارات النسخ
              _buildCopyOption(
                context: bottomCtx,
                icon: Icons.numbers_rounded,
                color: Colors.blue,
                title: 'نسخ الرقم 📱',
                subtitle: phone.isNotEmpty ? phone : 'لا يوجد رقم للنسخ',
                onTap: phone.isNotEmpty ? () {
                  Navigator.pop(bottomCtx);
                  _copyToClipboard(phone, 'تم نسخ الرقم: $phone');
                } : null,
              ),

              _buildCopyOption(
                context: bottomCtx,
                icon: Icons.person_rounded,
                color: Colors.purple,
                title: 'نسخ الاسم ✏️',
                subtitle: name.isNotEmpty ? name : 'لا يوجد اسم للنسخ',
                onTap: name.isNotEmpty ? () {
                  Navigator.pop(bottomCtx);
                  _copyToClipboard(name, 'تم نسخ الاسم: $name');
                } : null,
              ),

              _buildCopyOption(
                context: bottomCtx,
                icon: Icons.copy_all_rounded,
                color: const Color(0xFF00ADB5),
                title: 'نسخ الاسم والرقم معاً 📋',
                subtitle: name.isNotEmpty && phone.isNotEmpty ? '$name - $phone' : 'لا توجد بيانات كافية للنسخ',
                onTap: name.isNotEmpty && phone.isNotEmpty ? () {
                  Navigator.pop(bottomCtx);
                  final fullText = 'الاسم: $name\nالرقم: $phone';
                  _copyToClipboard(fullText, 'تم نسخ الاسم والرقم معاً');
                } : null,
              ),

              const SizedBox(height: 12),

              TextButton(
                onPressed: () => Navigator.pop(bottomCtx),
                child: const Text(
                  'إلغاء',
                  style: TextStyle(
                    fontFamily: 'Tajawal',
                    color: Colors.grey,
                    fontSize: 14,
                  ),
                ),
              ),

              const SizedBox(height: 8),
            ],
          ),
        );
      },
    );
  }

  Widget _buildCopyOption({
    required BuildContext context,
    required IconData icon,
    required Color color,
    required String title,
    required String subtitle,
    VoidCallback? onTap,
  }) {
    final isDark = Theme.of(context).brightness == Brightness.dark;
    final textColor = isDark ? Colors.white : const Color(0xFF0F172A);

    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 8),
        decoration: BoxDecoration(
          border: Border(
            bottom: BorderSide(
              color: Colors.grey.withOpacity(0.1),
            ),
          ),
        ),
        child: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: color.withOpacity(0.15),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontFamily: 'Tajawal',
                      fontWeight: FontWeight.bold,
                      color: textColor,
                      fontSize: 15,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: TextStyle(
                      fontFamily: 'Tajawal',
                      fontSize: 12,
                      color: Colors.grey[600],
                    ),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            if (onTap != null)
              Icon(Icons.chevron_right_rounded, color: Colors.grey[400], size: 20),
          ],
        ),
      ),
    );
  }

  // ==================== دوال الحذف مع الإلغاء ====================

  void _deleteAllContactsWithVerification() {
    final TextEditingController verifyController = TextEditingController();
    String? dialogError;

    if (_allContacts.isEmpty) {
      _showSnackBar('الخزنة فارغة بالفعل ولا توجد أسماء لحذفها!', isError: true);
      return;
    }

    if (_isDeleting) {
      _showSnackBar('جاري عملية حذف بالفعل، انتظر حتى تكتمل.', isError: true);
      return;
    }

    showDialog(
      context: context,
      barrierDismissible: false,
      useRootNavigator: false,
      builder: (dialogCtx) {
        return WillPopScope(
          onWillPop: () async => false,
          child: StatefulBuilder(
            builder: (context, setDialogState) {
              final isDark = Theme.of(dialogCtx).brightness == Brightness.dark;
              final dialogBg = isDark ? const Color(0xFF1E1E1E) : Colors.white;
              final dialogTxt = isDark ? Colors.white : const Color(0xFF0F172A);

              return AlertDialog(
                backgroundColor: dialogBg,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                title: const Row(
                  children: [
                    Icon(Icons.warning_amber_rounded, color: Colors.red, size: 28),
                    SizedBox(width: 8),
                    Text('حذف كلي للأسماء ⚠️', style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold, fontSize: 16)),
                  ],
                ),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'سيتم إزالة وحذف جميع الأسماء المخزنة في الخزنة نهائياً (${_allContacts.length} اسم).\nلا يمكن التراجع عن هذا الإجراء بعد بدئه.',
                      style: const TextStyle(fontFamily: 'Tajawal', fontSize: 12, height: 1.5, color: Colors.grey),
                    ),
                    const SizedBox(height: 16),
                    TextField(
                      controller: verifyController,
                      obscureText: true,
                      style: TextStyle(color: dialogTxt),
                      decoration: InputDecoration(
                        labelText: 'أدخل الماستر باسوورد للتأكيد',
                        labelStyle: const TextStyle(fontFamily: 'Tajawal', fontSize: 13),
                        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: Colors.red, width: 1.5),
                        ),
                      ),
                    ),
                    if (dialogError != null)
                      Padding(
                        padding: const EdgeInsets.only(top: 8),
                        child: Text(dialogError!, style: const TextStyle(color: Colors.redAccent, fontSize: 12, fontFamily: 'Tajawal')),
                      ),
                  ],
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(dialogCtx),
                    child: const Text('إلغاء', style: TextStyle(color: Colors.grey, fontFamily: 'Tajawal')),
                  ),
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                    onPressed: () async {
                      final passwordInput = verifyController.text;
                      if (passwordInput.isEmpty) {
                        setDialogState(() => dialogError = 'الرجاء إدخال الباسوورد أولاً.');
                        return;
                      }

                      if (DatabaseService.verifyMasterPassword(passwordInput)) {
                        Navigator.pop(dialogCtx);
                        _runDeleteAllWithStages();
                      } else {
                        setDialogState(() => dialogError = 'كلمة السر الماستر غير صحيحة!');
                      }
                    },
                    child: const Text('احذف الكل نهائياً 🗑️', style: TextStyle(color: Colors.white, fontFamily: 'Tajawal')),
                  ),
                ],
              );
            },
          ),
        );
      },
    );
  }

  void _runDeleteAllWithStages() {
    if (_isDeleting) return;

    _isDeleting = true;
    _shouldCancel = false;

    int currentStage = 1;
    double progress = 0.0;
    int deletedSuccess = 0;
    final total = _allContacts.length;
    String currentStatusText = 'جاري تحضير قاعدة البيانات وفك الارتباطات...';

    showDialog(
      context: context,
      barrierDismissible: false,
      useRootNavigator: false,
      builder: (progressDialogCtx) {
        return WillPopScope(
          onWillPop: () async => false,
          child: StatefulBuilder(
            builder: (context, setProgressState) {
              final isDark = Theme.of(progressDialogCtx).brightness == Brightness.dark;
              final dialogBg = isDark ? const Color(0xFF1E1E1E) : Colors.white;
              final dialogTxt = isDark ? Colors.white : const Color(0xFF0F172A);

              Future<void> startDeletingProcess() async {
                setProgressState(() {
                  currentStage = 2;
                  progress = 0.0;
                  deletedSuccess = 0;
                });

                const int batchSize = 15;

                for (int i = 0; i < total && !_shouldCancel; i += batchSize) {
                  final int end = (i + batchSize < total) ? i + batchSize : total;

                  String tempStatus = 'جاري إزالة الدفعة الأولى وتصفير المؤشرات... 🗑️';
                  if (i >= total * 0.3 && i < total * 0.7) {
                    tempStatus = 'جاري مسح السجلات وإلغاء فهرسة الأرقام... 🔒';
                  } else if (i >= total * 0.7) {
                    tempStatus = 'جاري إنهاء التعديلات وضغط قاعدة البيانات... 💾';
                  }

                  for (int j = i; j < end && !_shouldCancel; j++) {
                    final contact = _allContacts[j];
                    if (contact['id'] != null) {
                      try {
                        await DatabaseService.deleteContact(contact['id']);
                        deletedSuccess++;
                      } catch (e) {
                        debugPrint("Error deleting contact during batch: $e");
                      }
                    }
                  }

                  final double calculatedProgress = end / total;

                  if (progressDialogCtx.mounted && !_shouldCancel) {
                    setProgressState(() {
                      progress = calculatedProgress;
                      currentStatusText = tempStatus;
                    });
                  }

                  await Future.delayed(const Duration(milliseconds: 35));
                }

                if (progressDialogCtx.mounted) {
                  if (_shouldCancel) {
                    setProgressState(() {
                      currentStage = 4;
                    });
                  } else {
                    setProgressState(() {
                      currentStage = 3;
                    });
                  }
                }
              }

              return AlertDialog(
                backgroundColor: dialogBg,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                title: Text(
                  'معالج الحذف الآمن والنهائي 🗑️',
                  style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold, color: dialogTxt),
                  textAlign: TextAlign.center,
                ),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (currentStage == 1) ...[
                      const Icon(Icons.warning_amber_rounded, color: Colors.redAccent, size: 60),
                      const SizedBox(height: 16),
                      Text(
                        'المرحلة الأولى: فحص وتأكيد المسح',
                        style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold, color: dialogTxt, fontSize: 15),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'تم تحضير ($total) اسم للمسح النهائي.\nسيتم تنفيذ العملية على دفعات آمنة لضمان عدم تجمد نظام هاتف العميل.',
                        style: const TextStyle(fontFamily: 'Tajawal', fontSize: 13, color: Colors.grey),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 20),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                              onPressed: () {
                                startDeletingProcess();
                              },
                              child: const Text('ابدأ الحذف 🚀', style: TextStyle(fontFamily: 'Tajawal', color: Colors.white, fontWeight: FontWeight.bold)),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: OutlinedButton(
                              style: OutlinedButton.styleFrom(
                                side: const BorderSide(color: Colors.grey),
                              ),
                              onPressed: () {
                                _shouldCancel = true;
                                _isDeleting = false;
                                Navigator.pop(progressDialogCtx);
                                _showSnackBar('تم إلغاء عملية الحذف.', isError: false);
                              },
                              child: const Text('إلغاء ❌', style: TextStyle(fontFamily: 'Tajawal', color: Colors.grey)),
                            ),
                          ),
                        ],
                      ),
                    ],

                    if (currentStage == 2) ...[
                      const SizedBox(height: 10),
                      const SizedBox(
                        width: 50,
                        height: 50,
                        child: CircularProgressIndicator(
                          color: Colors.redAccent,
                          strokeWidth: 4,
                        ),
                      ),
                      const SizedBox(height: 20),
                      Text(
                        currentStatusText,
                        style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold, color: dialogTxt, fontSize: 13),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 16),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: LinearProgressIndicator(
                          value: progress,
                          backgroundColor: Colors.grey.withOpacity(0.2),
                          color: Colors.redAccent,
                          minHeight: 12,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        '${(progress * 100).toStringAsFixed(0)}% مكتمل',
                        style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold, color: dialogTxt, fontSize: 16),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'تم إزالة $deletedSuccess من أصل $total اسم بنجاح...',
                        style: const TextStyle(fontFamily: 'Tajawal', fontSize: 12, color: Colors.grey),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 12),
                      OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Colors.red),
                        ),
                        onPressed: () {
                          _shouldCancel = true;
                        },
                        child: const Text('إلغاء العملية ❌', style: TextStyle(color: Colors.red, fontFamily: 'Tajawal')),
                      ),
                    ],

                    if (currentStage == 3) ...[
                      const Icon(Icons.check_circle_outline_rounded, color: Colors.green, size: 60),
                      const SizedBox(height: 16),
                      Text(
                        'تم إفراغ الخزنة بالكامل! 🧹',
                        style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold, color: dialogTxt, fontSize: 15),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'تم حذف وتطهير قاعدة البيانات من جميع جهات الاتصال ($deletedSuccess اسم) بسلام وثبات تام 🚀',
                        style: const TextStyle(fontFamily: 'Tajawal', fontSize: 13, color: Colors.grey),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                        onPressed: () {
                          _isDeleting = false;
                          Navigator.pop(progressDialogCtx);
                          _loadContacts();
                          _showSnackBar('تم إفراغ قاعدة البيانات وتصفيرها بالكامل! 🧹✨');
                        },
                        child: const Text('إغلاق نافذة المعالج', style: TextStyle(fontFamily: 'Tajawal', color: Colors.white, fontWeight: FontWeight.bold)),
                      )
                    ],

                    if (currentStage == 4) ...[
                      const Icon(Icons.cancel_rounded, color: Colors.orange, size: 60),
                      const SizedBox(height: 16),
                      Text(
                        'تم إلغاء العملية! ⚠️',
                        style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold, color: dialogTxt, fontSize: 15),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'تم إلغاء عملية الحذف بعد حذف $deletedSuccess اسم.',
                        style: const TextStyle(fontFamily: 'Tajawal', fontSize: 13, color: Colors.grey),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                        onPressed: () {
                          _isDeleting = false;
                          Navigator.pop(progressDialogCtx);
                          _loadContacts();
                          _showSnackBar('تم إلغاء عملية الحذف.', isError: true);
                        },
                        child: const Text('إغلاق', style: TextStyle(fontFamily: 'Tajawal', color: Colors.white, fontWeight: FontWeight.bold)),
                      )
                    ]
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }

  // ==================== دوال الاستيراد مع الإلغاء ====================

  Future<void> _importFromPhoneDevice() async {
    if (_isImporting) {
      _showSnackBar('جاري عملية استيراد بالفعل، انتظر حتى تكتمل.', isError: true);
      return;
    }

    try {
      var status = await Permission.contacts.status;
      if (status.isDenied || status.isLimited) {
        status = await Permission.contacts.request();
      }

      if (status.isGranted) {
        showDialog(
          context: context,
          barrierDismissible: false,
          useRootNavigator: false,
          builder: (context) => WillPopScope(
            onWillPop: () async => false,
            child: const Center(
              child: CircularProgressIndicator(color: Color(0xFF00ADB5)),
            ),
          ),
        );

        List<Contact> contacts = await FlutterContacts.getContacts(withProperties: true);
        if (mounted) Navigator.pop(context);

        if (contacts.isEmpty) {
          _showSnackBar('لم يتم العثور على أي جهات اتصال في الهاتف.', isError: true);
          return;
        }

        contacts = contacts.where((c) => c.phones.isNotEmpty && _cleanPhoneNumber(c.phones.first.number).isNotEmpty).toList();

        final existingPhones = _allContacts.map((c) => _cleanPhoneNumber((c['phone'] ?? '').toString())).toSet();

        if (!mounted) return;

        showDialog(
          context: context,
          barrierDismissible: false,
          useRootNavigator: false,
          builder: (dialogCtx) {
            return WillPopScope(
              onWillPop: () async => false,
              child: StatefulBuilder(
                builder: (context, setDialogState) {
                  final theme = ThemeProvider.of(dialogCtx);
                  final isDark = theme != null ? theme.isDark : Theme.of(dialogCtx).brightness == Brightness.dark;
                  final dialogBg = isDark ? const Color(0xFF1E1E1E) : Colors.white;
                  final dialogTxt = isDark ? Colors.white : const Color(0xFF0F172A);

                  List<Contact> selectedContacts = contacts.where((c) {
                    final clean = _cleanPhoneNumber(c.phones.first.number);
                    return !existingPhones.contains(clean);
                  }).toList();

                  final searchControllerImport = TextEditingController();
                  List<Contact> filteredList = List.from(contacts);

                  void onSearchQueryChanged(String query) {
                    setDialogState(() {
                      if (query.isEmpty) {
                        filteredList = List.from(contacts);
                      } else {
                        filteredList = contacts.where((c) {
                          final name = c.displayName.toLowerCase();
                          final phone = c.phones.first.number;
                          return name.contains(query.toLowerCase()) || phone.contains(query);
                        }).toList();
                      }
                    });
                  }

                  return AlertDialog(
                    backgroundColor: dialogBg,
                    title: Column(
                      children: [
                        Text(
                          'استيراد من الهاتف 📱 (${contacts.length})',
                          style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold, color: dialogTxt, fontSize: 16),
                          textAlign: TextAlign.center,
                        ),
                        const SizedBox(height: 12),
                        TextField(
                          controller: searchControllerImport,
                          onChanged: onSearchQueryChanged,
                          style: TextStyle(color: dialogTxt, fontSize: 13),
                          decoration: InputDecoration(
                            hintText: 'ابحث عن اسم محدد للاستيراد...',
                            hintStyle: const TextStyle(fontSize: 12),
                            prefixIcon: const Icon(Icons.search, size: 18),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                            contentPadding: const EdgeInsets.symmetric(vertical: 8),
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            TextButton.icon(
                              icon: const Icon(Icons.select_all_rounded, size: 16, color: Color(0xFF00ADB5)),
                              label: const Text('تحديد الكل', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'Tajawal', color: Color(0xFF00ADB5))),
                              onPressed: () {
                                setDialogState(() {
                                  selectedContacts = List.from(contacts);
                                });
                              },
                            ),
                            TextButton.icon(
                              icon: const Icon(Icons.deselect_rounded, size: 16, color: Colors.grey),
                              label: const Text('إلغاء الكل', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'Tajawal', color: Colors.grey)),
                              onPressed: () {
                                setDialogState(() {
                                  selectedContacts.clear();
                                });
                              },
                            ),
                          ],
                        )
                      ],
                    ),
                    content: SizedBox(
                      width: double.maxFinite,
                      height: 300,
                      child: filteredList.isEmpty
                          ? const Center(child: Text('لا توجد نتائج مطابقة لبحثك.', style: TextStyle(fontFamily: 'Tajawal', fontSize: 13, color: Colors.grey)))
                          : ListView.builder(
                        itemCount: filteredList.length,
                        itemBuilder: (context, index) {
                          final contact = filteredList[index];
                          final displayName = contact.displayName.isEmpty ? "بدون اسم" : contact.displayName;
                          final phone = contact.phones.first.number;
                          final cleanPhone = _cleanPhoneNumber(phone);
                          final isAlreadyImported = existingPhones.contains(cleanPhone);
                          final isChecked = selectedContacts.contains(contact);

                          return CheckboxListTile(
                            activeColor: const Color(0xFF00ADB5),
                            title: Row(
                              children: [
                                Expanded(
                                  child: Text(displayName, style: TextStyle(fontFamily: 'Tajawal', fontSize: 13, color: dialogTxt, fontWeight: FontWeight.bold)),
                                ),
                                if (isAlreadyImported)
                                  Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                    decoration: BoxDecoration(color: Colors.red.withOpacity(0.1), borderRadius: BorderRadius.circular(6)),
                                    child: const Text('مكرر ⚠️', style: TextStyle(color: Colors.red, fontSize: 10, fontWeight: FontWeight.bold, fontFamily: 'Tajawal')),
                                  ),
                              ],
                            ),
                            subtitle: Text(phone, style: const TextStyle(fontSize: 11, color: Colors.grey)),
                            value: isChecked,
                            onChanged: (val) {
                              setDialogState(() {
                                if (val == true) {
                                  selectedContacts.add(contact);
                                } else {
                                  selectedContacts.remove(contact);
                                }
                              });
                            },
                          );
                        },
                      ),
                    ),
                    actions: [
                      TextButton(
                        onPressed: () => Navigator.pop(dialogCtx),
                        child: const Text('إلغاء', style: TextStyle(fontFamily: 'Tajawal', color: Colors.grey)),
                      ),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF00ADB5)),
                        onPressed: () async {
                          if (selectedContacts.isEmpty) {
                            _showSnackBar('الرجاء اختيار جهة اتصال واحدة على الأقل للاستيراد.', isError: true);
                            return;
                          }

                          Navigator.pop(dialogCtx);
                          _runImportWithStages(selectedContacts);
                        },
                        child: const Text('استيراد المحدد', style: TextStyle(fontFamily: 'Tajawal', color: Colors.white, fontWeight: FontWeight.bold)),
                      ),
                    ],
                  );
                },
              ),
            );
          },
        );
      } else if (status.isPermanentlyDenied) {
        _showSnackBar('تم رفض الوصول لجهات الاتصال بشكل دائم، يرجى تفعيلها من إعدادات الهاتف.', isError: true);
        openAppSettings();
      } else {
        _showSnackBar('تم رفض إذن الوصول لجهات الاتصال الخاصة بالهاتف.', isError: true);
      }
    } catch (e) {
      _showSnackBar('حدث خطأ أثناء محاولة الوصول لجهات الاتصال: $e', isError: true);
    }
  }

  void _runImportWithStages(List<Contact> selectedContacts) {
    if (_isImporting) return;

    _isImporting = true;
    _shouldCancel = false;

    int currentStage = 1;
    double progress = 0.0;
    int importedSuccess = 0;
    final total = selectedContacts.length;
    String currentStatusText = 'جاري التحضير وفك تشفير جهات الاتصال...';

    showDialog(
      context: context,
      barrierDismissible: false,
      useRootNavigator: false,
      builder: (progressDialogCtx) {
        return WillPopScope(
          onWillPop: () async => false,
          child: StatefulBuilder(
            builder: (context, setProgressState) {
              final isDark = Theme.of(progressDialogCtx).brightness == Brightness.dark;
              final dialogBg = isDark ? const Color(0xFF1E1E1E) : Colors.white;
              final dialogTxt = isDark ? Colors.white : const Color(0xFF0F172A);

              Future<void> startImportingProcess() async {
                setProgressState(() {
                  currentStage = 2;
                  progress = 0.0;
                  importedSuccess = 0;
                });

                const int batchSize = 10;

                for (int i = 0; i < total && !_shouldCancel; i += batchSize) {
                  final int end = (i + batchSize < total) ? i + batchSize : total;

                  String tempStatus = 'جاري قراءة ونقل البيانات من الهاتف... 📱';
                  if (i >= total * 0.3 && i < total * 0.7) {
                    tempStatus = 'جاري تشفير الأسماء وتأمينها في طبقة الحماية... 🔐';
                  } else if (i >= total * 0.7) {
                    tempStatus = 'جاري حفظ البيانات وتثبيتها بالخزنة المحلية... 💾';
                  }

                  for (int j = i; j < end && !_shouldCancel; j++) {
                    final contact = selectedContacts[j];
                    final name = contact.displayName.isEmpty ? "بدون اسم" : contact.displayName;
                    final rawPhone = contact.phones.isNotEmpty ? contact.phones.first.number : '';
                    final phone = _cleanPhoneNumber(rawPhone);

                    if (name.isNotEmpty && phone.isNotEmpty) {
                      try {
                        await DatabaseService.saveContact(
                          const Uuid().v4(),
                          name,
                          phone,
                          'مستورد من هاتف العميل',
                          folder: 'مستورد',
                          isFavorite: false,
                        );
                        importedSuccess++;
                      } catch (e) {
                        debugPrint("Error saving contact $name: $e");
                      }
                    }
                  }

                  final double calculatedProgress = end / total;

                  if (progressDialogCtx.mounted && !_shouldCancel) {
                    setProgressState(() {
                      progress = calculatedProgress;
                      currentStatusText = tempStatus;
                    });
                  }

                  await Future.delayed(const Duration(milliseconds: 35));
                }

                if (progressDialogCtx.mounted) {
                  if (_shouldCancel) {
                    setProgressState(() {
                      currentStage = 4;
                    });
                  } else {
                    setProgressState(() {
                      currentStage = 3;
                    });
                  }
                }
              }

              return AlertDialog(
                backgroundColor: dialogBg,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
                title: Text(
                  'معالج الاستيراد الآمن 🔒',
                  style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold, color: dialogTxt),
                  textAlign: TextAlign.center,
                ),
                content: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (currentStage == 1) ...[
                      const Icon(Icons.warning_amber_rounded, color: Colors.orange, size: 60),
                      const SizedBox(height: 16),
                      Text(
                        'المرحلة الأولى: فحص البيانات والتحضير',
                        style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold, color: dialogTxt, fontSize: 15),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'تم كشف ($total) اسم جاهز للاستيراد.\nسيتم تشفير وحفظ الأسماء بأعلى سرعة مع الحفاظ على استقرار النظام.',
                        style: const TextStyle(fontFamily: 'Tajawal', fontSize: 13, color: Colors.grey),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 20),
                      Row(
                        children: [
                          Expanded(
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF00ADB5)),
                              onPressed: () {
                                startImportingProcess();
                              },
                              child: const Text('ابدأ الآن 🚀', style: TextStyle(fontFamily: 'Tajawal', color: Colors.white, fontWeight: FontWeight.bold)),
                            ),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: OutlinedButton(
                              style: OutlinedButton.styleFrom(
                                side: const BorderSide(color: Colors.grey),
                              ),
                              onPressed: () {
                                _shouldCancel = true;
                                _isImporting = false;
                                Navigator.pop(progressDialogCtx);
                                _showSnackBar('تم إلغاء عملية الاستيراد.', isError: false);
                              },
                              child: const Text('إلغاء ❌', style: TextStyle(fontFamily: 'Tajawal', color: Colors.grey)),
                            ),
                          ),
                        ],
                      ),
                    ],

                    if (currentStage == 2) ...[
                      const SizedBox(height: 10),
                      const SizedBox(
                        width: 50,
                        height: 50,
                        child: CircularProgressIndicator(
                          color: Color(0xFF00ADB5),
                          strokeWidth: 4,
                        ),
                      ),
                      const SizedBox(height: 20),
                      Text(
                        currentStatusText,
                        style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold, color: dialogTxt, fontSize: 13),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 16),
                      ClipRRect(
                        borderRadius: BorderRadius.circular(10),
                        child: LinearProgressIndicator(
                          value: progress,
                          backgroundColor: Colors.grey.withOpacity(0.2),
                          color: const Color(0xFF00ADB5),
                          minHeight: 12,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Text(
                        '${(progress * 100).toStringAsFixed(0)}% مكتمل',
                        style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold, color: dialogTxt, fontSize: 16),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'تم معالجة وحفظ $importedSuccess من إجمالي $total اسم...',
                        style: const TextStyle(fontFamily: 'Tajawal', fontSize: 12, color: Colors.grey),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 12),
                      OutlinedButton(
                        style: OutlinedButton.styleFrom(
                          side: const BorderSide(color: Colors.red),
                        ),
                        onPressed: () {
                          _shouldCancel = true;
                        },
                        child: const Text('إلغاء العملية ❌', style: TextStyle(color: Colors.red, fontFamily: 'Tajawal')),
                      ),
                    ],

                    if (currentStage == 3) ...[
                      const Icon(Icons.check_circle_outline_rounded, color: Colors.green, size: 60),
                      const SizedBox(height: 16),
                      Text(
                        'تم الحفظ والتشفير بنجاح! 🔐',
                        style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold, color: dialogTxt, fontSize: 15),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'تم نقل وتشفير وحفظ $importedSuccess جهة اتصال محلياً في الخزنة بنجاح واستقرار تام 🚀',
                        style: const TextStyle(fontFamily: 'Tajawal', fontSize: 13, color: Colors.grey),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
                        onPressed: () {
                          _isImporting = false;
                          Navigator.pop(progressDialogCtx);
                          _loadContacts();
                          _showSnackBar('تم استيراد $importedSuccess جهة اتصال بنجاح! 🎉🔒');
                        },
                        child: const Text('إغلاق نافذة المعالج', style: TextStyle(fontFamily: 'Tajawal', color: Colors.white, fontWeight: FontWeight.bold)),
                      )
                    ],

                    if (currentStage == 4) ...[
                      const Icon(Icons.cancel_rounded, color: Colors.orange, size: 60),
                      const SizedBox(height: 16),
                      Text(
                        'تم إلغاء العملية! ⚠️',
                        style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold, color: dialogTxt, fontSize: 15),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 8),
                      Text(
                        'تم إلغاء عملية الاستيراد بعد استيراد $importedSuccess اسم.',
                        style: const TextStyle(fontFamily: 'Tajawal', fontSize: 13, color: Colors.grey),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 20),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: Colors.orange),
                        onPressed: () {
                          _isImporting = false;
                          Navigator.pop(progressDialogCtx);
                          _loadContacts();
                          _showSnackBar('تم إلغاء عملية الاستيراد.', isError: true);
                        },
                        child: const Text('إغلاق', style: TextStyle(fontFamily: 'Tajawal', color: Colors.white, fontWeight: FontWeight.bold)),
                      )
                    ]
                  ],
                ),
              );
            },
          ),
        );
      },
    );
  }

  // ==================== دوال إضافة/تعديل جهات الاتصال ====================

  void _openContactDialog({Map<String, dynamic>? contact}) {
    final bool isEdit = contact != null;
    final formKey = GlobalKey<FormState>();

    if (isEdit) {
      _nameController.text = contact['name'] ?? '';
      _phoneController.text = contact['phone'] ?? '';
      _notesController.text = contact['notes'] ?? '';
      _selectedFolder = contact['folder'] ?? 'عام';
      final fav = contact['isFavorite'];
      _isFavorite = (fav == true || fav == 1 || fav == 'true' || fav == '1');
    } else {
      _nameController.clear();
      _phoneController.clear();
      _notesController.clear();
      _selectedFolder = 'عام';
      _isFavorite = false;
    }

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (bottomSheetCtx) {
        final theme = ThemeProvider.of(bottomSheetCtx);
        final isDark = theme != null ? theme.isDark : Theme.of(bottomSheetCtx).brightness == Brightness.dark;
        final bg = isDark ? const Color(0xFF1E1E1E) : Colors.white;
        final textColor = isDark ? Colors.white : const Color(0xFF0F172A);

        return StatefulBuilder(
          builder: (context, setModalState) {
            return Container(
              decoration: BoxDecoration(
                color: bg,
                borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
              ),
              padding: EdgeInsets.only(
                top: 24,
                left: 24,
                right: 24,
                bottom: MediaQuery.of(bottomSheetCtx).viewInsets.bottom + 24,
              ),
              child: SingleChildScrollView(
                child: Form(
                  key: formKey,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Container(
                          width: 50,
                          height: 5,
                          decoration: BoxDecoration(
                            color: Colors.grey.withOpacity(0.3),
                            borderRadius: BorderRadius.circular(10),
                          ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      Text(
                        isEdit ? 'تعديل جهة الاتصال ✏️' : 'إضافة جهة اتصال جديدة 👤',
                        style: TextStyle(
                          color: textColor,
                          fontWeight: FontWeight.bold,
                          fontSize: 20,
                          fontFamily: 'Tajawal',
                        ),
                      ),
                      const SizedBox(height: 20),
                      TextFormField(
                        controller: _nameController,
                        style: TextStyle(color: textColor, fontFamily: 'Tajawal'),
                        validator: (v) => v == null || v.trim().isEmpty ? 'الرجاء إدخال الاسم بالكامل' : null,
                        decoration: InputDecoration(
                          labelText: 'الاسم بالكامل',
                          prefixIcon: const Icon(Icons.person_rounded, color: Color(0xFF00ADB5)),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _phoneController,
                        keyboardType: TextInputType.phone,
                        style: TextStyle(color: textColor, fontFamily: 'Tajawal'),
                        validator: (v) => v == null || v.trim().isEmpty ? 'الرجاء إدخال رقم الهاتف' : null,
                        decoration: InputDecoration(
                          labelText: 'رقم الهاتف (أو رقم الواتساب)',
                          prefixIcon: const Icon(Icons.phone_rounded, color: Color(0xFF00ADB5)),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextFormField(
                        controller: _notesController,
                        maxLines: 2,
                        style: TextStyle(color: textColor, fontFamily: 'Tajawal'),
                        decoration: InputDecoration(
                          labelText: 'ملاحظات إضافية',
                          prefixIcon: const Icon(Icons.notes_rounded, color: Color(0xFF00ADB5)),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                      ),
                      const SizedBox(height: 16),
                      DropdownButtonFormField<String>(
                        value: _selectedFolder,
                        dropdownColor: bg,
                        style: TextStyle(color: textColor, fontFamily: 'Tajawal'),
                        decoration: InputDecoration(
                          labelText: 'تصنيف المجموعة',
                          prefixIcon: const Icon(Icons.folder_open_rounded, color: Color(0xFF00ADB5)),
                          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        items: _folders.map((f) => DropdownMenuItem(value: f, child: Text(f))).toList(),
                        onChanged: (v) => setModalState(() => _selectedFolder = v!),
                      ),
                      const SizedBox(height: 12),
                      SwitchListTile(
                        activeColor: const Color(0xFF00ADB5),
                        title: Text('إضافة جهة الاتصال للمفضلة؟ ⭐', style: TextStyle(color: textColor, fontFamily: 'Tajawal', fontSize: 15)),
                        value: _isFavorite,
                        onChanged: (v) => setModalState(() => _isFavorite = v),
                      ),
                      const SizedBox(height: 24),
                      Row(
                        children: [
                          if (isEdit) ...[
                            Expanded(
                              child: OutlinedButton.icon(
                                style: OutlinedButton.styleFrom(
                                  side: const BorderSide(color: Colors.red),
                                  padding: const EdgeInsets.symmetric(vertical: 14),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                ),
                                icon: const Icon(Icons.delete_forever_rounded, color: Colors.red),
                                label: const Text('حذف', style: TextStyle(color: Colors.red, fontFamily: 'Tajawal', fontWeight: FontWeight.bold)),
                                onPressed: () => _confirmDelete(contact['id']),
                              ),
                            ),
                            const SizedBox(width: 12),
                          ],
                          Expanded(
                            child: ElevatedButton(
                              style: ElevatedButton.styleFrom(
                                backgroundColor: const Color(0xFF00ADB5),
                                padding: const EdgeInsets.symmetric(vertical: 14),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              ),
                              onPressed: () async {
                                if (formKey.currentState!.validate()) {
                                  try {
                                    final id = isEdit ? contact['id'] : const Uuid().v4();
                                    final cleanPhone = _cleanPhoneNumber(_phoneController.text.trim());

                                    await DatabaseService.saveContact(
                                      id,
                                      _nameController.text.trim(),
                                      cleanPhone,
                                      _notesController.text.trim(),
                                      folder: _selectedFolder,
                                      isFavorite: _isFavorite,
                                    );

                                    if (bottomSheetCtx.mounted) {
                                      Navigator.pop(bottomSheetCtx);
                                      _loadContacts();
                                      _showSnackBar(isEdit ? 'تم تحديث جهة الاتصال بنجاح! 💾' : 'تم حفظ جهة الاتصال وتأمينها بنجاح! 🔒');
                                    }
                                  } catch (e) {
                                    _showSnackBar('فشل حفظ البيانات: $e', isError: true);
                                  }
                                }
                              },
                              child: Text(isEdit ? 'تحديث' : 'تأمين وحفظ 🔐', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Tajawal', fontSize: 16)),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 12),
                    ],
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _confirmDelete(String id) {
    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('تأكيد الحذف ⚠️', style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold)),
        content: const Text('هل أنت متأكد من رغبتك في حذف جهة الاتصال هذه نهائياً من قاعدة البيانات المشفرة؟', style: TextStyle(fontFamily: 'Tajawal')),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext),
            child: const Text('إلغاء', style: TextStyle(fontFamily: 'Tajawal')),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            onPressed: () async {
              try {
                await DatabaseService.deleteContact(id);
                if (dialogContext.mounted) {
                  Navigator.pop(dialogContext);
                }
                if (mounted) {
                  Navigator.pop(context);
                  _loadContacts();
                  _showSnackBar('تم إزالة جهة الاتصال من الخزنة بنجاح 🗑️');
                }
              } catch (e) {
                _showSnackBar('حدث خطأ أثناء الحذف: $e', isError: true);
              }
            },
            child: const Text('نعم، احذف نهائياً', style: TextStyle(color: Colors.white, fontFamily: 'Tajawal')),
          ),
        ],
      ),
    );
  }

  void _openImportDialog() {
    final importController = TextEditingController();
    showDialog(
      context: context,
      builder: (dialogCtx) {
        return AlertDialog(
          title: const Text('استيراد جهات اتصال سريعة 📥', style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'انسخ والصق قائمة الأرقام والأسماء هنا بالشكل التالي:\nالاسم, الرقم\nأو الصق نص vCard مباشرة وسيقوم المحرك الذكي بتحليلها.',
                style: TextStyle(fontSize: 12, color: Colors.grey, fontFamily: 'Tajawal'),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: importController,
                maxLines: 6,
                decoration: InputDecoration(
                  hintText: "أحمد, 01234567890\nمحمد, +201099887766",
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogCtx),
              child: const Text('إلغاء', style: TextStyle(fontFamily: 'Tajawal')),
            ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF00ADB5)),
              onPressed: () async {
                final text = importController.text.trim();
                if (text.isEmpty) return;

                int importedCount = 0;
                final lines = text.split('\n');
                for (var line in lines) {
                  if (line.contains(',') || line.contains('-') || line.contains(':')) {
                    final parts = line.split(RegExp(r'[,:\-]'));
                    if (parts.length >= 2) {
                      final name = parts[0].trim();
                      final rawPhone = parts[1].trim();
                      final phone = _cleanPhoneNumber(rawPhone);

                      if (name.isNotEmpty && phone.isNotEmpty) {
                        try {
                          await DatabaseService.saveContact(
                            const Uuid().v4(),
                            name,
                            phone,
                            'مستورد تلقائياً',
                            folder: 'مستورد',
                            isFavorite: false,
                          );
                          importedCount++;
                        } catch (e) {
                          debugPrint("Error dynamic saving: $e");
                        }
                      }
                    }
                  }
                }

                if (dialogCtx.mounted) {
                  Navigator.pop(dialogCtx);
                  _loadContacts();
                  _showSnackBar('تم استيراد وتشفير $importedCount من جهات الاتصال بنجاح! 🎉🔒');
                }
              },
              child: const Text('بدء الاستيراد والتأمين', style: TextStyle(color: Colors.white, fontFamily: 'Tajawal')),
            ),
          ],
        );
      },
    );
  }

  // ==================== build ====================

  @override
  Widget build(BuildContext context) {
    final theme = ThemeProvider.of(context);
    final isDark = theme != null ? theme.isDark : Theme.of(context).brightness == Brightness.dark;
    final primaryTextColor = isDark ? Colors.white : const Color(0xFF0F172A);
    final cardColor = isDark ? const Color(0xFF1E1E1E) : Colors.white;

    final List<String> filterChips = ['الكل', 'المفضلة', ..._folders];

    return Scaffold(
      backgroundColor: isDark ? const Color(0xFF121212) : const Color(0xFFF5F5F5),
      appBar: AppBar(
        title: Text(
          'مدير جهات الاتصال الملوكي 👑',
          style: TextStyle(color: primaryTextColor, fontWeight: FontWeight.bold, fontFamily: 'Tajawal', fontSize: 18),
        ),
        centerTitle: true,
        backgroundColor: isDark ? const Color(0xFF1E1E1E) : Colors.white,
        elevation: 1,
        actions: [
          // 🆕 زر كتابة الرقم والاتصال
          IconButton(
            icon: const Icon(Icons.dialpad_rounded, color: Color(0xFF00ADB5)),
            tooltip: 'كتابة رقم والاتصال',
            onPressed: _showDialPad,
          ),
          IconButton(
            icon: const Icon(Icons.refresh_rounded, color: Color(0xFF00ADB5)),
            tooltip: 'تحديث جهات الاتصال',
            onPressed: _loadContacts,
          ),
          IconButton(
            icon: const Icon(Icons.import_contacts_rounded, color: Color(0xFF00ADB5)),
            tooltip: 'استيراد من جهات اتصال الهاتف',
            onPressed: _importFromPhoneDevice,
          ),
          IconButton(
            icon: const Icon(Icons.file_open_rounded, color: Color(0xFF25D366)),
            tooltip: 'استيراد سريع للجهات',
            onPressed: _openImportDialog,
          ),
          IconButton(
            icon: const Icon(Icons.delete_sweep_rounded, color: Colors.redAccent),
            tooltip: 'تفريغ وحذف جميع الأسماء',
            onPressed: _deleteAllContactsWithVerification,
          )
        ],
      ),
      body: Column(
        children: [
          // ==================== شريط البحث ====================
          Padding(
            padding: const EdgeInsets.only(left: 16, right: 16, top: 16, bottom: 8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _searchController,
                    style: TextStyle(color: primaryTextColor, fontFamily: 'Tajawal'),
                    decoration: InputDecoration(
                      hintText: 'ابحث بالاسم، الرقم، أو الملاحظات...',
                      hintStyle: const TextStyle(color: Colors.grey, fontSize: 13),
                      prefixIcon: const Icon(Icons.search_rounded, color: Color(0xFF00ADB5)),
                      suffixIcon: _searchController.text.isNotEmpty
                          ? IconButton(
                        icon: const Icon(Icons.clear, color: Colors.grey),
                        onPressed: () {
                          _searchController.clear();
                          _applyFiltersAndSearch();
                        },
                      )
                          : null,
                      filled: true,
                      fillColor: cardColor,
                      contentPadding: const EdgeInsets.symmetric(vertical: 12),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(16),
                        borderSide: BorderSide.none,
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10),
                  height: 48,
                  decoration: BoxDecoration(
                    color: cardColor,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<int>(
                      value: _pageSize,
                      dropdownColor: cardColor,
                      style: TextStyle(color: primaryTextColor, fontFamily: 'Tajawal', fontWeight: FontWeight.bold, fontSize: 12),
                      icon: const Icon(Icons.unfold_more_rounded, color: Color(0xFF00ADB5), size: 18),
                      items: [
                        ..._pageSizeOptions.map((size) => DropdownMenuItem(
                          value: size,
                          child: Text('$size اسم'),
                        )),
                        DropdownMenuItem(
                          value: -1,
                          child: Text('الكل (${_filteredContacts.length})'),
                        ),
                      ],
                      onChanged: (val) {
                        if (val != null) {
                          setState(() {
                            _pageSize = val;
                            _currentPage = 1;
                            _paginateContacts();
                          });
                        }
                      },
                    ),
                  ),
                ),
              ],
            ),
          ),

          // ==================== شريط الأحرف الأبجدية ====================
          Container(
            height: 42,
            margin: const EdgeInsets.symmetric(vertical: 4),
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: _alphabet.length,
              itemBuilder: (context, index) {
                final letter = _alphabet[index];
                final isSelected = _selectedLetter == letter;
                return GestureDetector(
                  onTap: () {
                    setState(() {
                      _selectedLetter = letter;
                      _currentPage = 1;
                      _applyFiltersAndSearch();
                    });
                  },
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
                    padding: const EdgeInsets.symmetric(horizontal: 12),
                    decoration: BoxDecoration(
                      color: isSelected ? const Color(0xFF00ADB5) : cardColor,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: isSelected ? const Color(0xFF00ADB5) : Colors.grey.withOpacity(0.15),
                      ),
                    ),
                    alignment: Alignment.center,
                    child: Text(
                      letter,
                      style: TextStyle(
                        fontFamily: 'Tajawal',
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                        color: isSelected ? Colors.white : (isDark ? Colors.grey : Colors.black54),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),

          // ==================== شريط التصفية ====================
          SizedBox(
            height: 48,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12),
              itemCount: filterChips.length,
              itemBuilder: (context, idx) {
                final chipName = filterChips[idx];
                final isSelected = _activeFilter == chipName;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: ChoiceChip(
                    label: Text(chipName, style: const TextStyle(fontFamily: 'Tajawal', fontSize: 12, fontWeight: FontWeight.bold)),
                    selected: isSelected,
                    selectedColor: const Color(0xFF00ADB5),
                    labelStyle: TextStyle(color: isSelected ? Colors.white : (isDark ? Colors.grey : Colors.black54)),
                    backgroundColor: cardColor,
                    onSelected: (selected) {
                      if (selected) {
                        setState(() {
                          _activeFilter = chipName;
                          _applyFiltersAndSearch();
                        });
                      }
                    },
                  ),
                );
              },
            ),
          ),

          // ==================== قائمة جهات الاتصال ====================
          Expanded(
            child: RefreshIndicator(
              onRefresh: () async {
                _loadContacts();
              },
              color: const Color(0xFF00ADB5),
              child: _displayedContacts.isEmpty
                  ? ListView(
                physics: const AlwaysScrollableScrollPhysics(),
                children: [
                  SizedBox(height: MediaQuery.of(context).size.height * 0.18),
                  Center(
                    child: Column(
                      children: [
                        Icon(Icons.contact_phone_rounded, size: 80, color: Colors.grey.withOpacity(0.4)),
                        const SizedBox(height: 16),
                        Text(
                          'لا توجد نتائج مطابقة لتصفيتك حالياً!',
                          style: TextStyle(fontSize: 16, color: primaryTextColor, fontFamily: 'Tajawal', fontWeight: FontWeight.bold),
                        ),
                        const SizedBox(height: 6),
                        const Text(
                          'اضغط على زر (+) لإضافة جهة اتصال، أو جرب فلاتر أخرى.',
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 13, color: Colors.grey, fontFamily: 'Tajawal'),
                        ),
                      ],
                    ),
                  ),
                ],
              )
                  : ListView.builder(
                controller: _scrollController,
                itemCount: _displayedContacts.length,
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 80),
                addAutomaticKeepAlives: false,
                addRepaintBoundaries: true,
                physics: const AlwaysScrollableScrollPhysics(),
                itemBuilder: (context, i) {
                  final item = _displayedContacts[i];
                  final isFavoriteItem = (item['isFavorite'] == true || item['isFavorite'] == 1 || item['isFavorite'] == 'true' || item['isFavorite'] == '1');
                  final folderLabel = item['folder'] ?? 'عام';

                  Color folderColor;
                  switch (folderLabel) {
                    case 'شخصي':
                      folderColor = Colors.purple;
                      break;
                    case 'عمل':
                      folderColor = Colors.blueAccent;
                      break;
                    case 'طوارئ':
                      folderColor = Colors.redAccent;
                      break;
                    case 'مستورد':
                      folderColor = Colors.teal;
                      break;
                    default:
                      folderColor = Colors.grey;
                  }

                  return Card(
                    color: cardColor,
                    elevation: 2,
                    margin: const EdgeInsets.symmetric(vertical: 6),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    child: InkWell(
                      borderRadius: BorderRadius.circular(16),
                      onTap: () => _openContactDialog(contact: item),
                      onLongPress: () => _showLongPressOptions(item), // 🆕 الضغط المطول للنسخ
                      child: Padding(
                        padding: const EdgeInsets.all(12.0),
                        child: Row(
                          children: [
                            Stack(
                              children: [
                                CircleAvatar(
                                  radius: 26,
                                  backgroundColor: const Color(0xFF00ADB5).withOpacity(0.1),
                                  child: Text(
                                    (item['name'] != null && item['name'].toString().isNotEmpty) ? item['name'].toString()[0] : '?',
                                    style: const TextStyle(color: Color(0xFF00ADB5), fontWeight: FontWeight.bold, fontSize: 18),
                                  ),
                                ),
                                if (isFavoriteItem)
                                  const Positioned(
                                    right: 0,
                                    bottom: 0,
                                    child: CircleAvatar(
                                      radius: 9,
                                      backgroundColor: Colors.amber,
                                      child: Icon(Icons.star, size: 12, color: Colors.white),
                                    ),
                                  ),
                              ],
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    item['name'] ?? '',
                                    style: TextStyle(
                                      color: primaryTextColor,
                                      fontWeight: FontWeight.bold,
                                      fontSize: 14,
                                      fontFamily: 'Tajawal',
                                    ),
                                    maxLines: 1,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    item['phone'] ?? '',
                                    style: const TextStyle(color: Colors.grey, fontSize: 13),
                                  ),
                                ],
                              ),
                            ),
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                              decoration: BoxDecoration(
                                color: folderColor.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                folderLabel,
                                style: TextStyle(color: folderColor, fontSize: 11, fontWeight: FontWeight.bold, fontFamily: 'Tajawal'),
                              ),
                            ),
                            const SizedBox(width: 8),

                            // 🆕 زر الرسائل
                            IconButton(
                              icon: const Icon(Icons.message_rounded, color: Color(0xFF00ADB5), size: 22),
                              onPressed: () => _showMessageOptions(item['phone'] ?? ''),
                              tooltip: 'إرسال رسالة',
                            ),
                            IconButton(
                              icon: const Icon(Icons.phone_in_talk_rounded, color: Colors.green, size: 22),
                              onPressed: () => _makePhoneCall(item['phone'] ?? ''),
                            ),
                          ],
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
          ),

          // ==================== شريط التنقل بين الصفحات ====================
          if (_totalPages > 1 && _pageSize != -1)
            Container(
              padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
              decoration: BoxDecoration(
                color: cardColor,
                border: Border(top: BorderSide(color: Colors.grey.withOpacity(0.15))),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF00ADB5),
                      disabledBackgroundColor: Colors.grey.withOpacity(0.3),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    ),
                    onPressed: _currentPage > 1
                        ? () {
                      setState(() {
                        _currentPage--;
                        _paginateContacts();
                      });
                    }
                        : null,
                    icon: const Icon(Icons.arrow_back_ios_new_rounded, size: 14, color: Colors.white),
                    label: const Text('السابق', style: TextStyle(fontFamily: 'Tajawal', fontSize: 13, color: Colors.white)),
                  ),
                  Text(
                    'صفحة $_currentPage من $_totalPages',
                    style: TextStyle(fontFamily: 'Tajawal', fontWeight: FontWeight.bold, color: primaryTextColor, fontSize: 13),
                  ),
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF00ADB5),
                      disabledBackgroundColor: Colors.grey.withOpacity(0.3),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    ),
                    onPressed: _currentPage < _totalPages
                        ? () {
                      setState(() {
                        _currentPage++;
                        _paginateContacts();
                      });
                    }
                        : null,
                    icon: const Icon(Icons.arrow_forward_ios_rounded, size: 14, color: Colors.white),
                    label: const Text('التالي', style: TextStyle(fontFamily: 'Tajawal', fontSize: 13, color: Colors.white)),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}