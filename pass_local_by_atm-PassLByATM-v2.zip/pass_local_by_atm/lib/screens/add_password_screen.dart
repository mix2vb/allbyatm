import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../models/password_model.dart';
import '../services/database_service.dart';

class AddPasswordScreen extends StatefulWidget {
  final PasswordModel? existingItem; // لو ممررناش حاجة هنا هتبقا إضافة، لو مررنا هتبقى تعديل
  const AddPasswordScreen({Key? key, this.existingItem}) : super(key: key);

  @override
  State<AddPasswordScreen> createState() => _AddPasswordScreenState();
}

class _AddPasswordScreenState extends State<AddPasswordScreen> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _titleController;
  late TextEditingController _urlController;
  late TextEditingController _usernameController;
  late TextEditingController _passwordController;

  String _selectedFolder = 'عام';
  bool _isFavorite = false;
  bool _obscurePassword = true;
  final List<String> _folders = ['شخصي', 'عمل', 'شبكات', 'عام'];

  @override
  void initState() {
    super.initState();
    // لو بنعدل، املأ الخانات بالبيانات القديمة تلقائياً
    _titleController = TextEditingController(text: widget.existingItem?.title ?? '');
    _urlController = TextEditingController(text: widget.existingItem?.url ?? '');
    _usernameController = TextEditingController(text: widget.existingItem?.username ?? '');
    _passwordController = TextEditingController(text: widget.existingItem?.password ?? '');
    _selectedFolder = widget.existingItem?.folder ?? 'عام';
    _isFavorite = widget.existingItem?.isFavorite ?? false;
  }

  void _save() async {
    if (_formKey.currentState!.validate()) {
      final updatedPassword = PasswordModel(
        // لو تعديل بناخد نفس الـ ID القديم عشان يمسح فوقه، لو إضافة بنعمل ID جديد تماماً
        id: widget.existingItem?.id ?? const Uuid().v4(),
        title: _titleController.text.trim(),
        url: _urlController.text.trim(),
        username: _usernameController.text.trim(),
        password: _passwordController.text.trim(),
        folder: _selectedFolder,
        isFavorite: _isFavorite,
      );

      await DatabaseService.savePassword(updatedPassword);
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('تم حفظ وتأمين البيانات داخل الخزنة 🔒', textDirection: TextDirection.rtl)),
        );
        Navigator.pop(context);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    bool isEdit = widget.existingItem != null;
    return Scaffold(
      appBar: AppBar(
        title: Text(isEdit ? 'تعديل بيانات الحساب' : 'إضافة حساب جديد'),
        centerTitle: true,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              TextFormField(controller: _titleController, validator: (v) => v!.isEmpty ? 'الرجاء إدخال الاسم' : null, decoration: const InputDecoration(labelText: 'اسم الموقع / الخدمة', filled: true)),
              const SizedBox(height: 16),
              TextFormField(controller: _urlController, decoration: const InputDecoration(labelText: 'الرابط (اللينك)', filled: true)),
              const SizedBox(height: 16),
              TextFormField(controller: _usernameController, validator: (v) => v!.isEmpty ? 'الرجاء إدخال اسم المستخدم' : null, decoration: const InputDecoration(labelText: 'اسم المستخدم / الإيميل', filled: true)),
              const SizedBox(height: 16),
              TextFormField(
                controller: _passwordController,
                obscureText: _obscurePassword,
                validator: (v) => v!.isEmpty ? 'الرجاء إدخال كلمة السر' : null,
                decoration: InputDecoration(
                  labelText: 'كلمة السر',
                  filled: true,
                  suffixIcon: IconButton(icon: Icon(_obscurePassword ? Icons.visibility_off : Icons.visibility), onPressed: () => setState(() => _obscurePassword = !_obscurePassword)),
                ),
              ),
              const SizedBox(height: 20),
              DropdownButtonFormField<String>(
                value: _selectedFolder,
                decoration: const InputDecoration(labelText: 'اختر الفولدر', filled: true),
                items: _folders.map((f) => DropdownMenuItem(value: f, child: Text(f))).toList(),
                onChanged: (v) => setState(() => _selectedFolder = v!),
              ),
              const SizedBox(height: 16),
              SwitchListTile(title: const Text('إضافة إلى المفضلات؟'), value: _isFavorite, onChanged: (v) => setState(() => _isFavorite = v)),
              const SizedBox(height: 32),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _save,
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF00ADB5)),
                  child: Text(isEdit ? 'تحديث البيانات الحالية' : 'حفظ الحساب بأمان', style: const TextStyle(color: Colors.white)),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}