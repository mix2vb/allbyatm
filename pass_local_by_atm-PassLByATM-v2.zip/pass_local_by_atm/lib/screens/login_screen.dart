import 'dart:math';
import 'package:flutter/material.dart';
import 'package:local_auth/local_auth.dart';
import '../services/database_service.dart';
import 'home_screen.dart';

class LoginScreen extends StatefulWidget {
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _passwordController = TextEditingController();
  final LocalAuthentication _auth = LocalAuthentication();
  bool _isLoading = false;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _authenticateWithBiometrics();
  }

  void _verifyWithRandomQuestion(String password) {
    final questions = DatabaseService.getSecurityQuestions();
    final isFirstQ = Random().nextBool();
    final activeQuestion = isFirstQ ? questions['q1']! : questions['q2']!;
    final answerController = TextEditingController();
    String? dialogError;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('تأكيد الهوية الإضافي', textAlign: TextAlign.center, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(activeQuestion, style: const TextStyle(color: Colors.blueGrey), textAlign: TextAlign.center),
              const SizedBox(height: 12),
              TextField(
                controller: answerController,
                decoration: const InputDecoration(hintText: 'اكتب إجابتك هنا', border: OutlineInputBorder()),
              ),
              if (dialogError != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(dialogError!, style: const TextStyle(color: Colors.red, fontSize: 12))),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
            ElevatedButton(
              onPressed: () async {
                // استدعاء الدوال المصححة هنا بنجاح وطبقاً لقواعد الـ Clean Code
                final savedA1 = DatabaseService.getSavedAnswer1();
                final savedA2 = DatabaseService.getSavedAnswer2();
                final inputAns = answerController.text.trim().toLowerCase();

                if ((isFirstQ && inputAns == savedA1) || (!isFirstQ && inputAns == savedA2)) {
                  Navigator.pop(context);
                  setState(() => _isLoading = true);
                  bool isSuccess = await DatabaseService.initDatabase(password);
                  setState(() => _isLoading = false);
                  if (isSuccess) _navigateToHome(password);
                } else {
                  setDialogState(() => dialogError = 'الإجابة لا تطابق السجلات الحالية!');
                }
              },
              child: const Text('دخول'),
            )
          ],
        ),
      ),
    );
  }

  void _login() async {
    final password = _passwordController.text;
    if (password.isEmpty) {
      setState(() => _errorMessage = 'الرجاء إدخال كلمة السر الفولاذية');
      return;
    }

    if (!DatabaseService.verifyMasterPassword(password)) {
      setState(() => _errorMessage = 'كلمة السر الماستر غير صحيحة!');
      return;
    }

    _verifyWithRandomQuestion(password);
  }

  Future<void> _authenticateWithBiometrics() async {
    try {
      bool canCheckBiometrics = await _auth.canCheckBiometrics;
      bool isDeviceSupported = await _auth.isDeviceSupported();

      if (canCheckBiometrics && isDeviceSupported) {
        bool didAuthenticate = await _auth.authenticate(
          localizedReason: 'ضع بصمتك لفتح الخزنة فوراً دون باسوورد',
          options: const AuthenticationOptions(biometricOnly: true, stickyAuth: true),
        );

        if (didAuthenticate) {
          final savedMaster = DatabaseService.getSavedMaster();
          if (savedMaster.isNotEmpty) {
            setState(() => _isLoading = true);
            bool isSuccess = await DatabaseService.initDatabase(savedMaster);
            setState(() => _isLoading = false);
            if (isSuccess) _navigateToHome(savedMaster);
          }
        }
      }
    } catch (e) {
      // تفادي أخطاء عدم دعم الجهاز للبصمة
    }
  }

  void _showFullRecoveryDialog() {
    final questions = DatabaseService.getSecurityQuestions();
    final a1Controller = TextEditingController();
    final a2Controller = TextEditingController();
    String? recoveryError;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: const Text('استرجاع كامل البيانات بأسئلة الأمان'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(questions['q1']!, style: const TextStyle(fontWeight: FontWeight.bold)),
                TextField(controller: a1Controller),
                const SizedBox(height: 16),
                Text(questions['q2']!, style: const TextStyle(fontWeight: FontWeight.bold)),
                TextField(controller: a2Controller),
                if (recoveryError != null) Padding(padding: const EdgeInsets.only(top: 8), child: Text(recoveryError!, style: const TextStyle(color: Colors.red)),),
              ],
            ),
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('إلغاء')),
            ElevatedButton(
              onPressed: () async {
                if (DatabaseService.verifySecurityAnswers(a1Controller.text, a2Controller.text)) {
                  Navigator.pop(context);
                  final savedMaster = DatabaseService.getSavedMaster();
                  await DatabaseService.initDatabase(savedMaster);
                  _navigateToHome(savedMaster);
                } else {
                  setDialogState(() => recoveryError = 'إجابات التحقق خاطئة!');
                }
              },
              child: const Text('تحقق وافتح الخزنة'),
            )
          ],
        ),
      ),
    );
  }

  void _navigateToHome(String pass) {
    Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => HomeScreen(masterPassword: pass)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.lock_person_rounded, size: 80, color: Color(0xFF00ADB5)),
              const SizedBox(height: 20),
              const Text('خزنة الأسرار المحلية', style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
              const SizedBox(height: 40),
              TextField(
                controller: _passwordController,
                obscureText: true,
                decoration: InputDecoration(
                  hintText: 'أدخل الماستر باسوورد الخاص بك',
                  prefixIcon: const Icon(Icons.vpn_key_rounded, color: Color(0xFF00ADB5)),
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                ),
              ),
              if (_errorMessage != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(_errorMessage!, style: const TextStyle(color: Colors.redAccent))),
              const SizedBox(height: 24),
              SizedBox(
                width: double.infinity,
                height: 50,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : _login,
                  style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF00ADB5)),
                  child: _isLoading ? const CircularProgressIndicator(color: Colors.white) : const Text('افتح الخزنة', style: TextStyle(color: Colors.white)),
                ),
              ),
              const SizedBox(height: 16),
              IconButton(
                icon: const Icon(Icons.fingerprint_rounded, size: 50, color: Color(0xFF00ADB5)),
                onPressed: _authenticateWithBiometrics,
              ),
              TextButton(
                onPressed: _showFullRecoveryDialog,
                child: const Text('نسيت كلمة السر؟ تخطي بأسئلة الأمان كاملة', style: TextStyle(color: Colors.grey)),
              )
            ],
          ),
        ),
      ),
    );
  }
}