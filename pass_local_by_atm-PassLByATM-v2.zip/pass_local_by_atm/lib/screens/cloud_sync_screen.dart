import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:hive/hive.dart'; // استيراد الهيف لضمان إمكانية فتح الصندوق برمجياً
import '../services/database_service.dart';
import '../services/backup_service.dart';
import '../main.dart';

class CloudSyncScreen extends StatefulWidget {
  final String masterPassword;
  const CloudSyncScreen({Key? key, required this.masterPassword}) : super(key: key);

  @override
  State<CloudSyncScreen> createState() => _CloudSyncScreenState();
}

class _CloudSyncScreenState extends State<CloudSyncScreen> {
  final _apiUrlController = TextEditingController();
  bool _isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadSavedUrl();
  }

  // دالة مساعدة للتأكد من أن صندوق Hive مفتوح قبل التعامل معه
  Future<Box> _ensureBoxOpen(String boxName) async {
    if (Hive.isBoxOpen(boxName)) {
      return Hive.box(boxName);
    } else {
      return await Hive.openBox(boxName);
    }
  }

  // جلب الرابط المحفوظ بأمان عند فتح الشاشة
  Future<void> _loadSavedUrl() async {
    try {
      // نفترض أن اسم الصندوق الخاص بالإعدادات هو 'settings' أو الاسم المستخدم في تطبيقك
      // تأكد من تمرير الاسم الصحيح لصندوق الإعدادات الخاص بك هنا (مثل 'settings' أو 'app_db')
      await _ensureBoxOpen('settings');

      final savedUrl = DatabaseService.getCloudApiUrl();
      _apiUrlController.text = savedUrl ?? '';
    } catch (e) {
      debugPrint("Error loading cloud API URL: $e");
      // محاولة بديلة في حال كان الصندوق باسم آخر، أو تركه فارغاً للمستخدم ليكتبه
      _apiUrlController.text = '';
    }
  }

  // دالة لحفظ الرابط في قاعدة البيانات مع إظهار رسالة للمستخدم
  Future<void> _manualSaveUrl() async {
    final url = _apiUrlController.text.trim();
    if (url.isEmpty) {
      _showSnackBar('الرجاء كتابة الرابط أولاً قبل الحفظ', isError: true);
      return;
    }
    try {
      // نضمن فتح الصندوق أولاً قبل الكتابة فيه لتجنب Box not found
      await _ensureBoxOpen('settings');

      await DatabaseService.saveCloudApiUrl(url);
      _showSnackBar('تم حفظ رابط الـ API بنجاح! لن تحتاج لكتابته مجدداً 💾🟢');
    } catch (e) {
      debugPrint("Manual save error: $e");
      _showSnackBar('حدث خطأ أثناء حفظ الرابط: ${e.toString()}', isError: true);
    }
  }

  // دالة الحفظ الصامتة لاستخدامها خلف الكواليس
  Future<void> _silentSaveUrl() async {
    final url = _apiUrlController.text.trim();
    if (url.isNotEmpty) {
      try {
        await _ensureBoxOpen('settings');
        await DatabaseService.saveCloudApiUrl(url);
      } catch (e) {
        debugPrint("Error saving URL silently: $e");
      }
    }
  }

  @override
  void dispose() {
    _apiUrlController.dispose();
    super.dispose();
  }

  void _showSnackBar(String msg, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text(msg, style: const TextStyle(fontFamily: 'Tajawal')),
      backgroundColor: isError ? Colors.redAccent : const Color(0xFF00ADB5),
      behavior: SnackBarBehavior.floating,
    ));
  }

  Future<void> _testConnection() async {
    final url = _apiUrlController.text.trim();
    if (url.isEmpty) {
      _showSnackBar('الرجاء إدخال رابط الـ API أولاً', isError: true);
      return;
    }

    setState(() => _isLoading = true);
    await _silentSaveUrl(); // حفظ تلقائي صامت للتأكيد

    try {
      final response = await http.post(
        Uri.parse(url),
        body: jsonEncode({'action': 'ping'}),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 10));

      final data = jsonDecode(response.body);
      if (response.statusCode == 200 && data['status'] == 'success') {
        _showSnackBar('تم الاتصال بنجاح! السيرفر الخاص بك جاهز ومتصل وعال العال 🟢');
      } else {
        _showSnackBar('السيرفر استجاب ولكن هناك مشكلة: ${data['message']}', isError: true);
      }
    } catch (e) {
      _showSnackBar('فشل الاتصال! تأكد من الرابط أو ملف الـ PHP المرفوع على موقعك.', isError: true);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _uploadBackup() async {
    final url = _apiUrlController.text.trim();
    if (url.isEmpty) {
      _showSnackBar('يرجى تهيئة رابط الـ API أولاً', isError: true);
      return;
    }

    setState(() => _isLoading = true);
    await _silentSaveUrl(); // ضمان حفظ وتحديث الرابط

    try {
      // فتح كافة الصناديق التي قد يحتاجها BackupService أثناء تجميع البيانات
      await _ensureBoxOpen('settings');
      // إذا كان لديك صناديق أخرى للبيانات (مثل 'notes' أو 'purchases') يفضل التأكد من فتحها هنا أيضاً:
      // await _ensureBoxOpen('your_data_box_name');

      String? backupData;
      String? errorMessage;

      try {
        backupData = await BackupService.getEncryptedBackupString(widget.masterPassword);
      } catch (e) {
        errorMessage = e.toString();
        debugPrint("Backup string generation error: $e");
      }

      if (backupData == null || backupData.trim().isEmpty) {
        String finalError = 'فشل توليد النسخة الاحتياطية! قد تكون قاعدة البيانات فارغة أو كلمة المرور غير صحيحة.';
        if (errorMessage != null) {
          finalError += '\nتفاصيل الخطأ: $errorMessage';
        }
        _showSnackBar(finalError, isError: true);
        return;
      }

      final response = await http.post(
        Uri.parse(url),
        body: jsonEncode({
          'action': 'upload',
          'backup_data': backupData,
          'timestamp': DateTime.now().toIso8601String(),
        }),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 20));

      final data = jsonDecode(response.body);
      if (response.statusCode == 200 && data['status'] == 'success') {
        _showSnackBar('تم المزامنة ورفع الباك أب المشفر على موقعك بنجاح ملوكي! ☁️🚀');
      } else {
        _showSnackBar('خطأ من السيرفر: ${data['message']}', isError: true);
      }
    } catch (e) {
      _showSnackBar('حدث خطأ غير متوقع أثناء الرفع: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  Future<void> _downloadBackup() async {
    final url = _apiUrlController.text.trim();
    if (url.isEmpty) {
      _showSnackBar('يرجى تهيئة رابط الـ API أولاً', isError: true);
      return;
    }

    setState(() => _isLoading = true);
    await _silentSaveUrl(); // ضمان حفظ وتحديث الرابط

    try {
      final response = await http.post(
        Uri.parse(url),
        body: jsonEncode({'action': 'download'}),
        headers: {'Content-Type': 'application/json'},
      ).timeout(const Duration(seconds: 20));

      final data = jsonDecode(response.body);
      if (response.statusCode == 200 && data['status'] == 'success') {
        String? encryptedData = data['backup_data'];

        if (encryptedData == null || encryptedData.isEmpty) {
          _showSnackBar('النسخة الاحتياطية المسترجعة من السيرفر فارغة!', isError: true);
          return;
        }

        // نضمن فتح الصناديق قبل الاستيراد وفك التشفير
        await _ensureBoxOpen('settings');

        bool success = await BackupService.importBackupFromString(encryptedData, widget.masterPassword);
        if (success) {
          _showSnackBar('تم تحميل واستعادة الباك أب من سيرفرك وفك التشفير بنجاح! 📥🟢');
        } else {
          _showSnackBar('فشل فك التشفير! تأكد من أن كلمة السر الحالية مطابقة للنسخة المخزنة على سيرفرك.', isError: true);
        }
      } else {
        _showSnackBar('خطأ من السيرفر: ${data['message']}', isError: true);
      }
    } catch (e) {
      _showSnackBar('حدث خطأ أثناء تحميل البيانات: $e', isError: true);
    } finally {
      if (mounted) setState(() => _isLoading = false);
    }
  }

  final String _phpCode = '''<?php
header("Content-Type: application/json; charset=UTF-8");
\$backupFile = "atm_secure_backup.json";

\$input = json_decode(file_get_contents("php://input"), true);
if (!\$input) {
    echo json_encode(["status" => "error", "message" => "لم يتم استلام أي بيانات من التطبيق."]);
    exit();
}

\$action = \$input['action'] ?? '';

if (\$action === 'ping') {
    echo json_encode(["status" => "success", "message" => "تم الاتصال بنجاح!"]);
} elseif (\$action === 'upload') {
    \$backupData = \$input['backup_data'] ?? '';
    if (empty(\$backupData)) {
        echo json_encode(["status" => "error", "message" => "البيانات المرسلة فارغة، فشل حفظ النسخة الاحتياطية."]);
        exit();
    }
    if (file_put_contents(\$backupFile, json_encode(["backup_data" => \$backupData, "timestamp" => \$input['timestamp']]))) {
        echo json_encode(["status" => "success", "message" => "تم حفظ النسخة الاحتياطية بنجاح على السيرفر!"]);
    } else {
        echo json_encode(["status" => "error", "message" => "فشل حفظ الملف على السيرفر، يرجى التأكد من صلاحيات المجلد."]);
    }
} elseif (\$action === 'download') {
    if (file_exists(\$backupFile)) {
        \$data = json_decode(file_get_contents(\$backupFile), true);
        echo json_encode(["status" => "success", "backup_data" => \$data['backup_data']]);
    } else {
        echo json_encode(["status" => "error", "message" => "عذراً، لا توجد نسخة احتياطية محفوظة على هذا السيرفر حتى الآن."]);
    }
} else {
    echo json_encode(["status" => "error", "message" => "طلب غير صالح أو غير مدعوم."]);
}
?>''';

  @override
  Widget build(BuildContext context) {
    final theme = ThemeProvider.of(context);
    final isDark = theme != null ? theme.isDark : Theme.of(context).brightness == Brightness.dark;
    final primaryTextColor = isDark ? Colors.white : const Color(0xFF0F172A);

    return Scaffold(
      backgroundColor: isDark ? const Color(0xFF121212) : const Color(0xFFF5F5F5),
      appBar: AppBar(
        title: Text('المزامنة السحابية الخاصة بك', style: TextStyle(color: primaryTextColor, fontWeight: FontWeight.bold, fontFamily: 'Tajawal')),
        centerTitle: true,
        backgroundColor: isDark ? const Color(0xFF1E1E1E) : Colors.white,
        elevation: 1,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.cloud_done_rounded, color: Color(0xFF00ADB5), size: 26),
                const SizedBox(width: 8),
                const Text('باك أب كلاود على موقعك الخاص', style: TextStyle(color: Color(0xFF00ADB5), fontSize: 18, fontWeight: FontWeight.bold, fontFamily: 'Tajawal')),
              ],
            ),
            const SizedBox(height: 10),
            const Text(
              'هذه الميزة الفريدة تتيح لك تخزين بياناتك المشفرة على خادمك أو موقعك الشخصي مباشرة، لا أحد يمتلك بياناتك غيرك أنت بشكل لامركزي ومحمي تماماً.',
              style: TextStyle(color: Colors.grey, fontSize: 13, height: 1.5, fontFamily: 'Tajawal'),
            ),
            const SizedBox(height: 25),

            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _apiUrlController,
                    style: TextStyle(color: primaryTextColor, fontFamily: 'Tajawal'),
                    decoration: InputDecoration(
                      labelText: 'رابط الـ API الخاص بموقعك',
                      labelStyle: TextStyle(color: isDark ? Colors.grey : Colors.black54, fontFamily: 'Tajawal'),
                      hintText: 'https://yourwebsite.com/backup_api.php',
                      hintStyle: const TextStyle(color: Colors.grey),
                      prefixIcon: const Icon(Icons.link_rounded, color: Color(0xFF00ADB5)),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                SizedBox(
                  height: 58,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF00ADB5),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                    ),
                    onPressed: _manualSaveUrl,
                    child: const Icon(Icons.save_rounded, color: Colors.white),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),

            _isLoading
                ? const Center(child: CircularProgressIndicator(color: Color(0xFF00ADB5)))
                : Column(
              children: [
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.blueAccent,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        icon: const Icon(Icons.settings_ethernet_rounded, color: Colors.white),
                        label: const Text('فحص الاتصال', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Tajawal')),
                        onPressed: _testConnection,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: const Color(0xFF25D366),
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        icon: const Icon(Icons.cloud_upload_rounded, color: Colors.white),
                        label: const Text('مزامنة ورفع الآن', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Tajawal')),
                        onPressed: _uploadBackup,
                      ),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: ElevatedButton.icon(
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.orange,
                          padding: const EdgeInsets.symmetric(vertical: 14),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        ),
                        icon: const Icon(Icons.cloud_download_rounded, color: Colors.white),
                        label: const Text('استعادة من السحابة', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontFamily: 'Tajawal')),
                        onPressed: _downloadBackup,
                      ),
                    ),
                  ],
                ),
              ],
            ),

            const SizedBox(height: 35),
            Divider(color: isDark ? Colors.white24 : Colors.black12),
            const SizedBox(height: 15),

            const Text('كيف تقوم بتهيئة موقعك الخاص؟', style: TextStyle(color: Color(0xFF00ADB5), fontSize: 16, fontWeight: FontWeight.bold, fontFamily: 'Tajawal')),
            const SizedBox(height: 8),
            const Text(
              'قم بنسخ هذا الكود البرمجي ووضعه داخل ملف باسم backup_api.php وارفعه على استضافة موقعك، ثم ضع رابط الملف في الحقل المخصص بالأعلى واضغط حفظ.',
              style: TextStyle(color: Colors.grey, fontSize: 12, height: 1.4, fontFamily: 'Tajawal'),
            ),
            const SizedBox(height: 14),

            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: isDark ? const Color(0xFF1E1E1E) : Colors.grey.shade200,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: isDark ? Colors.white12 : Colors.black12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text('ملف: backup_api.php', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13, color: Colors.grey, fontFamily: 'Tajawal')),
                      IconButton(
                        icon: const Icon(Icons.copy_rounded, color: Color(0xFF00ADB5), size: 20),
                        onPressed: () {
                          Clipboard.setData(ClipboardData(text: _phpCode));
                          _showSnackBar('تم نسخ كود الـ PHP لموقعك بنجاح! 📄💻');
                        },
                      )
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _phpCode,
                    maxLines: 8,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontFamily: 'monospace', fontSize: 11, color: Colors.blueGrey),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}