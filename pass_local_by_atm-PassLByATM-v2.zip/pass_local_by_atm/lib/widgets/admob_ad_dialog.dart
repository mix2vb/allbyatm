import 'package:flutter/material.dart';
// 🟢 استبدله بهذا الاستيراد الصحيح
import 'package:google_mobile_ads/google_mobile_ads.dart';

class AdMobAdDialog extends StatefulWidget {
  const AdMobAdDialog({Key? key}) : super(key: key);

  @override
  State<AdMobAdDialog> createState() => _AdMobAdDialogState();
}

class _AdMobAdDialogState extends State<AdMobAdDialog> {
  BannerAd? _bannerAd;
  bool _isAdLoaded = false;
  int _secondsRemaining = 5;
  bool _canClose = false;

  // معرف الإعلان التجريبي من جوجل للبانر (استبدله بمعرف إعلانك الحقيقي عند النشر)
  final String _adUnitId = 'ca-app-pub-3778989833117134/2552959375';

  @override
  void initState() {
    super.initState();
    _loadAdMobBanner();
    _startCountdown();
  }

  void _loadAdMobBanner() {
    _bannerAd = BannerAd(
      adUnitId: _adUnitId,
      size: AdSize.mediumRectangle, // حجم مستطيل ممتاز يناسب الـ Dialog (300x250)
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          setState(() {
            _isAdLoaded = true;
          });
        },
        onAdFailedToLoad: (ad, error) {
          debugPrint('AdMob Ad failed to load: $error');
          ad.dispose();
        },
      ),
    )..load();
  }

  void _startCountdown() {
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted) return false;
      setState(() {
        if (_secondsRemaining > 0) {
          _secondsRemaining--;
        }
        if (_secondsRemaining == 0) {
          _canClose = true;
        }
      });
      return _secondsRemaining > 0;
    });
  }

  @override
  void dispose() {
    _bannerAd?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _canClose,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('يرجى الانتظار حتى انتهاء الإعلان ولدعم التطبيق 🤝', textDirection: TextDirection.rtl),
              duration: Duration(seconds: 1),
            ),
          );
        }
      },
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: Stack(
            children: [
              Center(
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.85,
                  height: 400,
                  margin: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade900,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: const Color(0xFF00ADB5).withOpacity(0.3), width: 1.5),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(22),
                    child: _isAdLoaded && _bannerAd != null
                        ? Center(
                      child: SizedBox(
                        width: _bannerAd!.size.width.toDouble(),
                        height: _bannerAd!.size.height.toDouble(),
                        child: AdWidget(ad: _bannerAd!),
                      ),
                    )
                        : const Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          CircularProgressIndicator(color: Color(0xFF00ADB5)),
                          SizedBox(height: 16),
                          Text('جاري تحميل إعلان ملوكي آمن... 🔒', style: TextStyle(color: Colors.white70, fontSize: 13)),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              Positioned(
                top: 36,
                left: 36,
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  child: _canClose
                      ? Container(
                    key: const ValueKey('close_btn'),
                    decoration: const BoxDecoration(color: Colors.redAccent, shape: BoxShape.circle),
                    child: IconButton(
                      icon: const Icon(Icons.close_rounded, color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                  )
                      : Container(
                    key: const ValueKey('counter_txt'),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: Colors.black.withOpacity(0.6), shape: BoxShape.circle),
                    child: Text(
                      '$_secondsRemaining',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}