import 'dart:math';
import 'package:flutter/material.dart';
import 'custom_image_ad_dialog.dart';
import 'admob_ad_dialog.dart';

class AdsDispatcher {
  /// ترجع ويدجت الإعلان المناسب بناءً على اختيار عشوائي (50% لكل نوع)
  static Widget getRandomAdDialog() {
    final random = Random();
    final isAdMob = random.nextBool(); // ترجع true أو false بشكل عشوائي تماماً

    if (isAdMob) {
      debugPrint("AdsDispatcher: تم اختيار إعلان AdMob");
      return const AdMobAdDialog();
    } else {
      debugPrint("AdsDispatcher: تم اختيار إعلان البانر الملوكي الخاص");
      return const CustomImageAdDialog();
    }
  }

  /// لو أردت فرض إعلان معين يدوياً في أي وقت (للاختبار مثلاً)
  static Widget getSpecificAdDialog({required bool useAdMob}) {
    return useAdMob ? const AdMobAdDialog() : const CustomImageAdDialog();
  }
}