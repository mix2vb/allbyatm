import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class CustomImageAdDialog extends StatefulWidget {
  const CustomImageAdDialog({Key? key}) : super(key: key);

  @override
  State<CustomImageAdDialog> createState() => _CustomImageAdDialogState();
}

class _CustomImageAdDialogState extends State<CustomImageAdDialog> {
  int _secondsRemaining = 5;
  bool _canClose = false;

  final String _adImageUrl = 'https://poundos.com/ByATM-500.png';
  final String _destinationUrl = 'https://wa.me/201091499989';

  @override
  void initState() {
    super.initState();
    _startCountdown();
  }

  void _startCountdown() {
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted) return false;
      setState(() {
        if (_secondsRemaining > 0) {
          _secondsRemaining--;
        }
        if (_secondsRemaining == 0) {
          _canClose = true;
        }
      });
      return _secondsRemaining > 0;
    });
  }

  Future<void> _launchURL() async {
    final Uri url = Uri.parse(_destinationUrl);
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      debugPrint('Could not launch $_destinationUrl');
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _canClose,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('يرجى الانتظار حتى انتهاء الإعلان ولدعم التطبيق 🤝', textDirection: TextDirection.rtl),
              duration: Duration(seconds: 1),
            ),
          );
        }
      },
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: Stack(
            children: [
              Center(
                child: Container(
                  width: MediaQuery.of(context).size.width * 0.85,
                  height: 400,
                  margin: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade900,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: const Color(0xFF00ADB5).withOpacity(0.3), width: 1.5),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(22),
                    child: GestureDetector(
                      onTap: _launchURL,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          Image.network(
                            _adImageUrl,
                            fit: BoxFit.contain,
                            loadingBuilder: (context, child, loadingProgress) {
                              if (loadingProgress == null) return child;
                              return const Center(
                                child: CircularProgressIndicator(color: Color(0xFF00ADB5)),
                              );
                            },
                            errorBuilder: (context, error, stackTrace) {
                              return const Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.broken_image_rounded, color: Colors.grey, size: 64),
                                    SizedBox(height: 12),
                                    Text('يدعم التطبيق بإظهار هذا الإعلان ماديًا 🤝', style: TextStyle(color: Colors.white70)),
                                  ],
                                ),
                              );
                            },
                          ),
                          Positioned.fill(
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [Colors.black.withOpacity(0.4), Colors.transparent, Colors.transparent],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              Positioned( // 🟢 تم التصحيح ليعمل زر الإغلاق والعداد بشكل ممتاز
                top: 36,
                left: 36,
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  child: _canClose
                      ? Container(
                    key: const ValueKey('close_btn'),
                    decoration: const BoxDecoration(color: Colors.redAccent, shape: BoxShape.circle),
                    child: IconButton(
                      icon: const Icon(Icons.close_rounded, color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                  )
                      : Container(
                    key: const ValueKey('counter_txt'),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: Colors.black.withOpacity(0.6), shape: BoxShape.circle),
                    child: Text(
                      '$_secondsRemaining',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}