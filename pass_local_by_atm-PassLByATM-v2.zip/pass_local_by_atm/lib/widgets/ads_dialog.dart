import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class AdBannerDialog extends StatefulWidget {
  const AdBannerDialog({Key? key}) : super(key: key);

  @override
  State<AdBannerDialog> createState() => _AdBannerDialogState();
}

class _AdBannerDialogState extends State<AdBannerDialog> {
  int _secondsRemaining = 5;
  bool _canClose = false;

  final String _adImageUrl = 'https://poundos.com/ByATM-500.png';
  final String _destinationUrl = 'https://wa.me/201091499989';

  @override
  void initState() {
    super.initState();
    _startCountdown();
  }

  void _startCountdown() {
    Future.doWhile(() async {
      await Future.delayed(const Duration(seconds: 1));
      if (!mounted) return false;
      setState(() {
        if (_secondsRemaining > 0) {
          _secondsRemaining--;
        }
        if (_secondsRemaining == 0) {
          _canClose = true;
        }
      });
      return _secondsRemaining > 0;
    });
  }

  Future<void> _launchURL() async {
    final Uri url = Uri.parse(_destinationUrl);
    if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
      debugPrint('Could not launch $_destinationUrl');
    }
  }

  @override
  Widget build(BuildContext context) {
    return PopScope(
      canPop: _canClose,
      onPopInvokedWithResult: (didPop, result) {
        if (!didPop) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('يرجى الانتظار حتى انتهاء الإعلان ولدعم التطبيق 🤝', textDirection: TextDirection.rtl),
              duration: Duration(seconds: 1),
            ),
          );
        }
      },
      child: Scaffold(
        backgroundColor: Colors.transparent,
        body: SafeArea(
          child: Stack(
            children: [
              // محتوى الإعلان
              Center(
                child: Container(
                  // 🟢 هنا يمكنك التحكم في أبعاد الإعلان بدقة ملوكية 🟢
                  width: MediaQuery.of(context).size.width * 0.85, // يعادل 85% من عرض الشاشة
                  height: 400, // الارتفاع الثابت بالبكسل (تستطيع تغييره لـ 300 أو 500 حسب تصميم بنرك)
                  margin: const EdgeInsets.all(24),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade900,
                    borderRadius: BorderRadius.circular(24),
                    border: Border.all(color: const Color(0xFF00ADB5).withOpacity(0.3), width: 1.5),
                  ),
                  child: ClipRRect(
                    borderRadius: BorderRadius.circular(22),
                    child: GestureDetector(
                      onTap: _launchURL,
                      child: Stack(
                        fit: StackFit.expand,
                        children: [
                          Image.network(
                            _adImageUrl,
                            // 🟢 تضمن هذه القيمة ملاءمة الصورة بالكامل داخل الأبعاد المحددة دون قص أطرافها
                            fit: BoxFit.contain,
                            loadingBuilder: (context, child, loadingProgress) {
                              if (loadingProgress == null) return child;
                              return const Center(
                                child: CircularProgressIndicator(color: Color(0xFF00ADB5)),
                              );
                            },
                            errorBuilder: (context, error, stackTrace) {
                              return const Center(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(Icons.broken_image_rounded, color: Colors.grey, size: 64),
                                    SizedBox(height: 12),
                                    Text('يدعم التطبيق بإظهار هذا الإعلان ماديًا 🤝', style: TextStyle(color: Colors.white70)),
                                  ],
                                ),
                              );
                            },
                          ),

                          // طبقة تظليل خفيفة علوية
                          Positioned.fill(
                            child: Container(
                              decoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: Alignment.topCenter,
                                  end: Alignment.bottomCenter,
                                  colors: [Colors.black.withOpacity(0.4), Colors.transparent, Colors.transparent],
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),

              // زر الإغلاق والعداد يتبع الحاوية بالأعلى ليكون ثابتاً في مكانه الملوكي
              Positioned(
                top: 36,
                left: 36,
                child: AnimatedSwitcher(
                  duration: const Duration(milliseconds: 300),
                  child: _canClose
                      ? Container(
                    key: const ValueKey('close_btn'),
                    decoration: const BoxDecoration(color: Colors.redAccent, shape: BoxShape.circle),
                    child: IconButton(
                      icon: const Icon(Icons.close_rounded, color: Colors.white),
                      onPressed: () => Navigator.pop(context),
                    ),
                  )
                      : Container(
                    key: const ValueKey('counter_txt'),
                    padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: Colors.black.withOpacity(0.6), shape: BoxShape.circle),
                    child: Text(
                      '$_secondsRemaining',
                      style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 15),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}