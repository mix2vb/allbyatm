package com.passlocal.byatm.pass_local_by_atm

import io.flutter.embedding.android.FlutterFragmentActivity

class MainActivity: FlutterFragmentActivity() {
    // تم التغيير بنجاح لدعم شاشة البصمة ونظام الحماية اللوكال
}